'use client';

import * as React from 'react';
import Link from 'next/link';
import { ArrowRight, Search } from 'lucide-react';
import { payments, getRecentPayments } from '@/data/payments';
import { issues } from '@/data/issues';
import { getGreeting } from '@/lib/utils';
import { MetricCard } from '@/components/ui/MetricCard';
import { IssueCard } from '@/components/ui/IssueCard';
import { PaymentTable } from '@/components/payment/PaymentTable';
import { Button } from '@/components/ui/Button';

export default function OverviewPage() {
  const greeting = getGreeting();
  const recentPayments = getRecentPayments(8);
  const actionableIssues = issues.filter((issue) => issue.status === 'action_required');
  const monitoredIssueCount = issues.filter(
    (issue) => issue.status === 'investigating' || issue.status === 'monitoring'
  ).length;

  return (
    <div className="space-y-8 pb-12">
      {/* Hero: focus on merchant decisions, not raw system activity. */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-border-subtle">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-content-primary">
            {greeting}, Acme Technologies
          </h1>
          <p className="text-xs sm:text-sm text-content-secondary mt-1 flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-content-primary" />
            <span>{actionableIssues.length} tasks need your attention</span>
            <span className="text-content-tertiary">·</span>
            <span>{monitoredIssueCount} events are being monitored automatically</span>
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <Link href="/payments">
            <Button variant="outline" size="sm" className="gap-1.5">
              <Search className="h-3.5 w-3.5" />
              <span>Find a payment</span>
            </Button>
          </Link>
          <Link href="/issues">
            <Button variant="primary" size="sm" className="gap-1.5">
              <span>Review {actionableIssues.length} tasks</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </Link>
        </div>
      </div>

      {/* The only three health signals most merchants need each day. */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <MetricCard
          label="Payment Health"
          value="98.2%"
          delta="1.4%"
          deltaType="positive"
          subtitle="98.2% conversion rate over last 24 hours"
        />

        <MetricCard
          label="Settlement Health"
          value="Healthy"
          statusText="On Track"
          statusType="healthy"
          subtitle="Next settlement ₹4,82,400 expected tomorrow"
        />

        <MetricCard
          label="Account Health"
          value="92"
          delta="100"
          deltaType="neutral"
          statusText="Healthy"
          statusType="healthy"
          subtitle="Compliance & KYC verified · 1 review pending"
        />
      </div>

      {/* Action queue: background signals stay out of the way until they need a person. */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold tracking-tight text-content-primary">
                Your next steps
              </h2>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-surface-tertiary text-content-secondary border border-border-subtle">
                {actionableIssues.length} to review
              </span>
            </div>
            <p className="text-xs text-content-secondary mt-0.5">
              Resolve is handling {monitoredIssueCount} other signals in the background.
            </p>
          </div>

          <Link
            href="/issues"
            className="text-xs font-semibold text-content-primary hover:text-content-secondary flex items-center gap-1 transition-colors"
          >
            <span>Open Action Center</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          {actionableIssues.map((issue) => (
            <IssueCard key={issue.id} issue={issue} variant="compact" />
          ))}
        </div>
      </div>

      {/* Recent payments remain one click away from a complete detail view. */}
      <div className="space-y-4 pt-2">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold tracking-tight text-content-primary">
              Recent Transactions
            </h2>
            <p className="text-xs text-content-secondary mt-0.5">
              Live transaction telemetry synced with banking gateway
            </p>
          </div>

          <Link
            href="/payments"
            className="text-xs font-semibold text-content-primary hover:text-content-secondary flex items-center gap-1 transition-colors"
          >
            <span>View full ledger ({payments.length})</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        <PaymentTable payments={recentPayments} showFilters={false} limit={6} />
      </div>
    </div>
  );
}
