import type { Metadata } from 'next';
import './globals.css';
import { AppShell } from '@/components/layout/AppShell';

export const metadata: Metadata = {
  title: 'Razorpay Resolve — Know what happened. Know what to do next.',
  description:
    'An intelligent payment resolution and diagnostic layer for Razorpay merchants.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,400;0,500;0,600;0,700;0,800&display=swap"
          rel="stylesheet"
        />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                const savedTheme = localStorage.getItem('rzp_theme');
                const useDark = savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches);
                document.documentElement.classList.toggle('dark', useDark);
              } catch (_) {}
            `,
          }}
        />
      </head>
      <body className="min-h-screen bg-surface-primary text-content-primary antialiased selection:bg-slate-200 selection:text-content-primary font-sans">
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
