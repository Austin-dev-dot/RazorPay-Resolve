'use client';

import * as React from 'react';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import {
  ArrowLeft,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  LifeBuoy,
  FileCode,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { payments, getPaymentById } from '@/data/payments';
import { PageShell } from '@/components/layout/PageShell';
import { PaymentSummary } from '@/components/payment/PaymentSummary';
import { PaymentTimeline } from '@/components/payment/PaymentTimeline';
import { ResolutionStep } from '@/components/resolution/ResolutionStep';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

interface PaymentDetailPageProps {
  params: {
    id: string;
  };
}

export default function PaymentDetailPage({ params }: PaymentDetailPageProps) {
  const payment = getPaymentById(params.id) || payments[0];
  const [showRawPayload, setShowRawPayload] = React.useState(false);

  // Dynamic explanation content based on payment status
  const isPendingMismatch =
    payment.status === 'pending' || payment.id === 'pay_8F92kLm4Tn9Qx2';
  const isUnderReview = payment.status === 'under_review';
  const isFailed = payment.status === 'failed';

  const whatHappened = isPendingMismatch
    ? "The customer's bank has indicated that the payment was successful, but final confirmation has not yet reached Razorpay."
    : isUnderReview
    ? "The customer's card was charged, but international 3DS step-up verification is pending card issuer clearance."
    : isFailed
    ? `The transaction was declined by the customer's bank (${payment.bankName || 'Issuing Bank'}). Reason: ${payment.errorDescription || 'Insufficient funds or card limit exceeded'}.`
    : 'The transaction completed normally and funds are accounted for in your next settlement.';

  const whatWeAreDoing = isPendingMismatch
    ? [
        'Monitoring the transaction continuously',
        'Checking for delayed bank confirmation via NPCI UDIR protocol',
        'Automatically reconciling the payment upon arrival',
        'Initiating automatic recovery if confirmation fails',
      ]
    : isUnderReview
    ? [
        'Holding inventory reservation for 30 minutes',
        'Polling international card acquirer network',
        'Preparing automatic refund if authentication times out',
      ]
    : isFailed
    ? [
        'Logged specific issuer error code for pattern analysis',
        'Verified customer bank has not retained debit hold',
        'Generated smart retry link for customer',
      ]
    : [
        'Scheduled for automated settlement into your verified bank account',
        'Invoiced GST and merchant service fee accounted for',
      ];

  const whatYouNeedToDo = isPendingMismatch
    ? 'Nothing. We are monitoring this automatically. Do not ask the customer to pay again.'
    : isUnderReview
    ? 'Nothing right now. The status will update automatically within 15 minutes.'
    : isFailed
    ? 'You can send the customer a 1-click alternative payment link to complete their purchase.'
    : 'No action required. Fulfill the order as usual.';

  return (
    <div className="space-y-8 pb-16">
      {/* Top back navigation */}
      <div className="flex items-center justify-between pb-3 border-b border-border-subtle">
        <Link
          href="/payments"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-content-secondary hover:text-content-primary transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to All Payments</span>
        </Link>

        <div className="flex items-center gap-2">
          <Link href="/support">
            <Button variant="outline" size="sm" className="gap-1.5 text-xs">
              <LifeBuoy className="h-3.5 w-3.5" />
              <span>Diagnose in Support</span>
            </Button>
          </Link>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setShowRawPayload(!showRawPayload)}
            className="gap-1.5 text-xs"
          >
            <FileCode className="h-3.5 w-3.5" />
            <span>{showRawPayload ? 'Hide API Payload' : 'View API Payload'}</span>
          </Button>
        </div>
      </div>

      {/* Raw Payload Inspector (Toggled) */}
      {showRawPayload && (
        <div className="p-5 rounded-2xl bg-slate-900 text-slate-200 text-xs font-mono shadow-elevated border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-[11px] pb-2 border-b border-slate-800 text-emerald-400">
            <span>// RAZORPAY GATEWAY RAW PAYLOAD — {payment.id}</span>
            <span className="text-slate-400">Read-Only Telemetry</span>
          </div>
          <pre className="overflow-x-auto text-[11px] leading-relaxed p-2">
            {JSON.stringify(
              {
                id: payment.id,
                entity: 'payment',
                amount: payment.amount,
                currency: payment.currency,
                status: payment.status,
                order_id: payment.orderId,
                method: payment.method,
                customer: payment.customer,
                bank: payment.bankName,
                bank_status: payment.bankStatus,
                webhook_delivered: payment.webhookDelivered,
                fee: payment.fee,
                tax: payment.tax,
                created_at: payment.createdAt,
              },
              null,
              2
            )}
          </pre>
        </div>
      )}

      {/* 1. Payment Summary Header */}
      <PaymentSummary payment={payment} />

      {/* 2. Reassurance / Resolution Layer (What Happened / What We're Doing / What You Need To Do) */}
      <ResolutionStep
        whatHappened={whatHappened}
        whatWeAreDoing={whatWeAreDoing}
        whatYouNeedToDo={whatYouNeedToDo}
        actionRequired={isFailed}
        actionButtonLabel={isFailed ? 'Send Retry Payment Link' : undefined}
        onActionClick={
          isFailed
            ? () =>
                alert(
                  `Payment retry link sent to ${payment.customer.email} via WhatsApp & Email!`
                )
            : undefined
        }
      />

      {/* 3. Visual Transaction Timeline */}
      <Card className="p-6 md:p-8 border-border">
        <PaymentTimeline events={payment.timeline} />
      </Card>
    </div>
  );
}
