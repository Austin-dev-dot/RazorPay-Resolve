'use client';

import * as React from 'react';
import Link from 'next/link';
import {
  CreditCard,
  Filter,
  Download,
  AlertTriangle,
  ArrowRight,
  LifeBuoy,
} from 'lucide-react';
import { payments } from '@/data/payments';
import { PageShell } from '@/components/layout/PageShell';
import { PaymentTable } from '@/components/payment/PaymentTable';
import { Button } from '@/components/ui/Button';

export default function PaymentsPage() {
  const atRiskCount = payments.filter(
    (p) => p.status === 'pending' || p.status === 'under_review' || p.status === 'disputed'
  ).length;

  return (
    <PageShell
      title="Payments & Transactions"
      subtitle="Real-time transaction stream with automated status verification and failure root-cause analysis."
      badge={
        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
          {payments.length} Total
        </span>
      }
      actions={
        <div className="flex items-center gap-2.5">
          <Link href="/support">
            <Button variant="outline" size="sm" className="gap-1.5">
              <LifeBuoy className="h-3.5 w-3.5" />
              <span>Diagnose Payment</span>
            </Button>
          </Link>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => alert('Exporting sanitized transaction ledger CSV...')}
            className="gap-1.5"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export CSV</span>
          </Button>
        </div>
      }
    >
      <div className="space-y-6">
        {/* At Risk Quick Filter Banner */}
        {atRiskCount > 0 && (
          <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-200/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse" />
              <span className="text-xs font-semibold text-amber-900">
                {atRiskCount} payments currently require monitoring or resolution.
              </span>
            </div>
            <Link
              href="/payments/pay_8F92kLm4Tn9Qx2"
              className="text-xs font-semibold text-accent hover:underline flex items-center gap-1"
            >
              <span>Inspect ₹4,999 unresolved UPI</span>
              <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
        )}

        <PaymentTable
          payments={payments}
          showFilters={true}
          title="Gateway Transaction Ledger"
        />
      </div>
    </PageShell>
  );
}
