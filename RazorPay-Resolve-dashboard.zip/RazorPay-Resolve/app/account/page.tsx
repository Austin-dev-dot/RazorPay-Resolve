'use client';

import * as React from 'react';
import Link from 'next/link';
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Clock,
  ExternalLink,
  Lock,
  Info,
} from 'lucide-react';
import { accountHealth, kycIssue } from '@/data/account';
import { PageShell } from '@/components/layout/PageShell';
import { HealthScore } from '@/components/ui/HealthScore';
import { KYCResolution } from '@/components/resolution/KYCResolution';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

export default function AccountHealthPage() {
  return (
    <PageShell
      title="Account Health & Compliance"
      subtitle="Proactive monitoring of your regulatory standing, payment reliability, chargeback safety, and KYC verification."
      badge={
        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
          Status: Healthy (92/100)
        </span>
      }
    >
      <div className="space-y-8 pb-16">
        {/* Top Hero: Health Score Card */}
        <Card className="p-6 md:p-8 border-border bg-gradient-to-br from-white via-white to-slate-50/60 shadow-card">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <HealthScore score={accountHealth.overallScore} maxScore={100} />

            <div className="flex items-center gap-3">
              <Link href="#kyc-troubleshoot">
                <Button variant="outline" size="sm" className="gap-1.5">
                  <Lock className="h-3.5 w-3.5 text-accent" />
                  <span>View KYC Verification</span>
                </Button>
              </Link>
            </div>
          </div>

          {/* Breakdown Categories Grid */}
          <div className="mt-8 pt-6 border-t border-border-subtle grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {accountHealth.categories.map((cat, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-surface-primary border border-border-subtle">
                <span className="text-[10px] font-bold uppercase tracking-wider text-content-tertiary block">
                  {cat.label}
                </span>
                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-content-primary tabular-nums">
                    {cat.score}
                  </span>
                  <span className="text-[11px] font-medium text-content-tertiary">/ 100</span>
                </div>
                <p className="text-xs text-content-secondary mt-1 leading-snug">
                  {cat.description}
                </p>
              </div>
            ))}
          </div>
        </Card>

        {/* Things to Watch (Proactive Rather Than Scary) */}
        <div className="space-y-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-amber-500" />
              <h3 className="text-base font-bold text-content-primary">Things to Watch</h3>
            </div>
            <p className="text-xs text-content-secondary mt-0.5">
              Early warning indicators detected by Resolve before they affect operations
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {accountHealth.warnings.map((warn) => (
              <Card
                key={warn.id}
                className="p-5 border-border flex items-center justify-between gap-4 hover:border-slate-300 transition-all"
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                      warn.severity === 'warning'
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-blue-50 text-blue-700 border border-blue-200'
                    }`}
                  >
                    {warn.severity === 'warning' ? (
                      <AlertTriangle className="h-4 w-4" />
                    ) : (
                      <Clock className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-content-primary leading-snug">
                      {warn.message}
                    </h4>
                    <span className="text-[11px] text-content-tertiary mt-0.5 block">
                      Proactive notification · No immediate penalty
                    </span>
                  </div>
                </div>

                {warn.actionLabel && (
                  <Link href={warn.actionHref || '#'}>
                    <Button variant="secondary" size="sm" className="gap-1 text-xs shrink-0">
                      <span>{warn.actionLabel}</span>
                      <ArrowRight className="h-3 w-3" />
                    </Button>
                  </Link>
                )}
              </Card>
            ))}
          </div>
        </div>

        {/* KYC & Onboarding Troubleshooting Experience (Scenario 4) */}
        <div id="kyc-troubleshoot" className="space-y-4 pt-4 border-t border-border-subtle">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-accent" />
              <h3 className="text-base font-bold text-content-primary">
                Onboarding & KYC Troubleshooting
              </h3>
            </div>
            <p className="text-xs text-content-secondary mt-0.5">
              Specific discrepancy identification without restarting the entire onboarding process
            </p>
          </div>

          <KYCResolution kycIssue={kycIssue} />
        </div>
      </div>
    </PageShell>
  );
}
