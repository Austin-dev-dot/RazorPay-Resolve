'use client';

import * as React from 'react';
import Link from 'next/link';
import {
  Search,
  Sparkles,
  LifeBuoy,
  CheckCircle2,
  RefreshCw,
  Send,
  HelpCircle,
  FileCheck,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react';
import { payments } from '@/data/payments';
import { PageShell } from '@/components/layout/PageShell';
import { DiagnosticResult } from '@/components/resolution/DiagnosticResult';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

export default function SupportPage() {
  const [searchQuery, setSearchQuery] = React.useState(
    'Customer paid but dashboard says failed'
  );
  const [isDiagnosing, setIsDiagnosing] = React.useState(false);
  const [diagnosedPayment, setDiagnosedPayment] = React.useState(payments[0]); // pay_8F92kLm4Tn9Qx2

  const presets = [
    {
      label: 'Customer paid but dashboard says failed',
      query: 'Customer paid but dashboard says failed',
      paymentId: 'pay_8F92kLm4Tn9Qx2',
    },
    {
      label: 'Check pay_8F92kLm4Tn9Qx2',
      query: 'pay_8F92kLm4Tn9Qx2',
      paymentId: 'pay_8F92kLm4Tn9Qx2',
    },
    {
      label: 'International payment decline (pay_K2mN...)',
      query: 'pay_K2mN7pQ4Rl8Wx5',
      paymentId: 'pay_K2mN7pQ4Rl8Wx5',
    },
    {
      label: 'Why is my settlement on hold?',
      query: 'Settlement hold on ₹1.24L',
      paymentId: 'pay_8F92kLm4Tn9Qx2',
    },
  ];

  const handleDiagnose = (queryToRun: string, targetPaymentId?: string) => {
    setIsDiagnosing(true);
    setSearchQuery(queryToRun);

    setTimeout(() => {
      setIsDiagnosing(false);
      const target =
        payments.find((p) => p.id === targetPaymentId) ||
        payments.find(
          (p) =>
            p.id.toLowerCase().includes(queryToRun.toLowerCase()) ||
            p.customer.name.toLowerCase().includes(queryToRun.toLowerCase())
        ) ||
        payments[0];

      setDiagnosedPayment(target);
    }, 700);
  };

  return (
    <PageShell
      title="Resolve an Issue"
      subtitle="Enter a payment ID, settlement reference, or plain-English problem. Our diagnostic engine maps banking telemetry to pinpoint the root cause."
      badge={
        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-indigo-50 text-accent border border-indigo-100">
          Automated Triage Layer
        </span>
      }
    >
      <div className="space-y-8 pb-16">
        {/* Diagnostic Search Box */}
        <Card className="p-6 md:p-8 border-border shadow-card bg-gradient-to-b from-white to-slate-50/50">
          <div className="max-w-2xl">
            <span className="text-xs font-bold uppercase tracking-wider text-accent block">
              Automated Diagnosis Search
            </span>
            <h3 className="text-xl font-bold tracking-tight text-content-primary mt-1">
              What went wrong?
            </h3>
            <p className="text-xs text-content-secondary mt-1">
              We correlate issuer CBS logs, NPCI status codes, and webhook queues instantly.
            </p>

            <div className="mt-4 relative flex items-center">
              <Search className="h-4 w-4 text-content-tertiary absolute left-4" />
              <input
                type="text"
                placeholder="Enter payment ID, settlement ID or describe the problem..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleDiagnose(searchQuery);
                }}
                className="w-full pl-11 pr-28 py-3.5 rounded-xl border border-border bg-white text-xs font-medium text-content-primary placeholder:text-content-tertiary focus:border-accent outline-none shadow-inner-glow transition-all"
              />
              <Button
                size="sm"
                variant="primary"
                onClick={() => handleDiagnose(searchQuery)}
                disabled={!searchQuery.trim() || isDiagnosing}
                className="absolute right-2 text-xs gap-1.5"
              >
                {isDiagnosing ? (
                  <>
                    <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    <span>Analyzing...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-3.5 w-3.5 text-indigo-200" />
                    <span>Diagnose</span>
                  </>
                )}
              </Button>
            </div>

            {/* Presets */}
            <div className="mt-3 flex items-center gap-2 flex-wrap">
              <span className="text-[11px] font-semibold text-content-tertiary">
                Try asking:
              </span>
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleDiagnose(preset.query, preset.paymentId)}
                  className="text-[11px] px-2.5 py-1 rounded-full bg-surface-tertiary text-content-secondary hover:text-content-primary hover:bg-slate-200/80 transition-colors border border-border-subtle cursor-pointer"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* Live Diagnostic Result */}
        {diagnosedPayment && !isDiagnosing && (
          <div className="space-y-4">
            <DiagnosticResult
              payment={diagnosedPayment}
              diagnosis="This appears to be a payment state mismatch. The customer's bank confirmed debit via UPI network (NPCI UTR received), but final acknowledgment was delayed by an acquirer network timeout. Razorpay automated reconciler is already monitoring and will sync state without customer or merchant intervention."
              nextCheckMinutes={2}
            />
          </div>
        )}

        {/* Support Guarantee & Merchant Trust Pillars */}
        <div className="pt-4 border-t border-border-subtle grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs">
          <div className="p-4 rounded-xl bg-white border border-border-subtle">
            <div className="flex items-center gap-2 font-semibold text-content-primary">
              <ShieldCheck className="h-4 w-4 text-emerald-600" />
              <span>Full Diagnostic Trace Attached</span>
            </div>
            <p className="text-content-secondary mt-1.5 leading-relaxed">
              If an issue requires specialist escalation, we automatically attach all gateway logs,
              UPI UTRs, and bank response codes. You never repeat yourself.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-white border border-border-subtle">
            <div className="flex items-center gap-2 font-semibold text-content-primary">
              <Sparkles className="h-4 w-4 text-accent" />
              <span>99.4% Automated Recovery</span>
            </div>
            <p className="text-content-secondary mt-1.5 leading-relaxed">
              State mismatches typically self-heal within 15–30 minutes through automated UDIR
              bank polling without manual tickets.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-white border border-border-subtle">
            <div className="flex items-center gap-2 font-semibold text-content-primary">
              <FileCheck className="h-4 w-4 text-indigo-600" />
              <span>Zero Jargon Explanations</span>
            </div>
            <p className="text-content-secondary mt-1.5 leading-relaxed">
              We translate cryptic ISO-8583 and Finacle error codes into plain language: what
              happened, whether money is safe, and what to do next.
            </p>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
