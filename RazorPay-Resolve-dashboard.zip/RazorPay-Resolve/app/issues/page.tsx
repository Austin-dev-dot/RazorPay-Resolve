'use client';

import * as React from 'react';
import { issues } from '@/data/issues';
import { PageShell } from '@/components/layout/PageShell';
import { IssueCard } from '@/components/ui/IssueCard';
import { EmptyState } from '@/components/ui/EmptyState';

export default function IssueCenterPage() {
  const [selectedCategory, setSelectedCategory] = React.useState<string>('all');

  const categories: { label: string; value: string }[] = [
    { label: 'All updates', value: 'all' },
    { label: 'Payments', value: 'payment' },
    { label: 'Settlements', value: 'settlement' },
    { label: 'Account', value: 'account' },
    { label: 'KYC & Compliance', value: 'kyc' },
  ];

  const filteredIssues = issues.filter((issue) => {
    if (selectedCategory === 'all') return true;
    return issue.category === selectedCategory;
  });

  const actionRequiredIssues = filteredIssues.filter((issue) => issue.status === 'action_required');
  const monitoringIssues = filteredIssues.filter(
    (issue) => issue.status === 'investigating' || issue.status === 'monitoring'
  );
  const completedIssues = filteredIssues.filter((issue) => issue.status === 'resolved');

  return (
    <PageShell
      title="Action Center"
      subtitle="Your tasks come first. Resolve quietly monitors everything else and lets you know when your input is needed."
      badge={
        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-surface-tertiary text-content-secondary border border-border-subtle">
          {issues.filter((issue) => issue.status === 'action_required').length} tasks
        </span>
      }
    >
      <div className="space-y-8">
        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none border-b border-border-subtle">
          {categories.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setSelectedCategory(cat.value)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all select-none cursor-pointer whitespace-nowrap ${
                selectedCategory === cat.value
                  ? 'bg-content-primary text-white dark:bg-[#f5f5f7] dark:text-[#1d1d1f] shadow-sm font-semibold'
                  : 'bg-surface-secondary text-content-secondary hover:text-content-primary border border-border-subtle hover:border-slate-300'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {filteredIssues.length === 0 ? (
          <EmptyState
            title="No issues in this category"
            description="All payment and compliance operations in this category are operating normally."
          />
        ) : (
          <div className="space-y-8">
            {/* Only show the merchant's actual work at the top. */}
            {actionRequiredIssues.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-content-primary" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-content-primary">
                    Needs your input ({actionRequiredIssues.length})
                  </h3>
                </div>
                <div className="space-y-4">
                  {actionRequiredIssues.map((issue) => (
                    <IssueCard key={issue.id} issue={issue} variant="detailed" />
                  ))}
                </div>
              </div>
            )}

            {/* These events are deliberately de-emphasized because Resolve is on them. */}
            {monitoringIssues.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-content-secondary" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-content-secondary">
                    Resolve is monitoring ({monitoringIssues.length})
                  </h3>
                </div>
                <div className="space-y-4">
                  {monitoringIssues.map((issue) => (
                    <IssueCard key={issue.id} issue={issue} variant="detailed" />
                  ))}
                </div>
              </div>
            )}

            {completedIssues.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-content-tertiary" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-content-secondary">
                    Completed updates ({completedIssues.length})
                  </h3>
                </div>
                <div className="space-y-4">
                  {completedIssues.map((issue) => (
                    <IssueCard key={issue.id} issue={issue} variant="detailed" />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </PageShell>
  );
}
