'use client';

import * as React from 'react';
import Link from 'next/link';
import { ArrowLeft, AlertTriangle, ShieldCheck, ArrowRight } from 'lucide-react';
import { issues, getIssueById } from '@/data/issues';
import { kycIssue } from '@/data/account';
import { settlementHold } from '@/data/settlements';
import { PageShell } from '@/components/layout/PageShell';
import { FailureIntelligence } from '@/components/payment/FailureIntelligence';
import { ResolutionStep } from '@/components/resolution/ResolutionStep';
import { SettlementCard } from '@/components/ui/SettlementCard';
import { KYCResolution } from '@/components/resolution/KYCResolution';
import { Card } from '@/components/ui/Card';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Button } from '@/components/ui/Button';

interface IssueDetailPageProps {
  params: {
    id: string;
  };
}

export default function IssueDetailPage({ params }: IssueDetailPageProps) {
  const issue = getIssueById(params.id) || issues[1]; // defaults to issue_002

  return (
    <div className="space-y-8 pb-16">
      {/* Back button */}
      <div className="flex items-center justify-between pb-3 border-b border-border-subtle">
        <Link
          href="/issues"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-content-secondary hover:text-content-primary transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to Issue Center</span>
        </Link>

        <div className="flex items-center gap-2">
          <StatusBadge severity={issue.severity} size="sm" />
          <StatusBadge issueStatus={issue.status} size="sm" />
        </div>
      </div>

      {/* Pattern Intelligence View (If isPattern) */}
      {issue.isPattern ? (
        <FailureIntelligence issue={issue} />
      ) : issue.category === 'kyc' ? (
        <KYCResolution kycIssue={kycIssue} />
      ) : issue.category === 'settlement' ? (
        <div className="space-y-6">
          <SettlementCard hold={settlementHold} />
        </div>
      ) : (
        <div className="space-y-6">
          <Card className="p-6 md:p-8 border-border">
            <h2 className="text-xl font-bold text-content-primary">{issue.title}</h2>
            <p className="text-sm text-content-secondary mt-1">{issue.description}</p>
          </Card>

          <ResolutionStep
            whatHappened={issue.explanation}
            whatWeAreDoing={[
              'Continuous status monitoring active',
              'Checking bank network clearance logs',
              'Queued for automatic recovery or ledger credit',
            ]}
            whatYouNeedToDo={issue.whatToDo}
          />
        </div>
      )}
    </div>
  );
}
