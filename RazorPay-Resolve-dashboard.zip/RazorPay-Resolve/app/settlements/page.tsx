'use client';

import * as React from 'react';
import {
  Wallet,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Building2,
  Check,
  X,
  Sparkles,
} from 'lucide-react';
import {
  settlements,
  settlementHold as initialHold,
  getNextSettlement,
  getUpcomingSettlements,
  getRecentSettlements,
} from '@/data/settlements';
import { formatCurrency } from '@/lib/utils';
import { PageShell } from '@/components/layout/PageShell';
import { SettlementCard } from '@/components/ui/SettlementCard';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

export default function SettlementsPage() {
  const [hold, setHold] = React.useState(initialHold);
  const [verificationModalOpen, setVerificationModalOpen] = React.useState(false);
  const [step2Confirmed, setStep2Confirmed] = React.useState(false);
  const [step3Signed, setStep3Signed] = React.useState(false);
  const [isVerifying, setIsVerifying] = React.useState(false);
  const [isResolved, setIsResolved] = React.useState(false);

  const nextSettlement = getNextSettlement();
  const upcomingSettlements = getUpcomingSettlements();
  const recentSettlements = getRecentSettlements();

  const handleCompleteVerification = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setIsResolved(true);
      setVerificationModalOpen(false);
      setHold((prev) => ({
        ...prev,
        steps: prev.steps.map((s) => ({ ...s, completed: true })),
      }));
    }, 1200);
  };

  return (
    <PageShell
      title="Settlement Health"
      subtitle="Automated payouts into your verified bank account. Daily T+1 settlement cycles with regulatory escrow protection."
      badge={
        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
          Settlement Health: Healthy
        </span>
      }
    >
      <div className="space-y-8 pb-16">
        {/* Top 3 Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Next Settlement */}
          <Card className="p-6 border-border flex flex-col justify-between">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-content-tertiary">
                Next Settlement
              </span>
              <div className="mt-2 text-3xl font-bold tracking-tight text-content-primary tabular-nums">
                ₹4,82,400
              </div>
              <p className="text-xs text-content-secondary mt-1">
                Expected: <strong className="text-content-primary">Tomorrow, 6:00 AM</strong>
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-border-subtle flex items-center justify-between text-xs text-content-secondary">
              <span>HDFC Bank (****4892)</span>
              <span className="text-emerald-700 font-medium">Auto-Nodal</span>
            </div>
          </Card>

          {/* Card 2: Settlement Health */}
          <Card className="p-6 border-border flex flex-col justify-between">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-content-tertiary">
                Settlement Health
              </span>
              <div className="mt-2 flex items-center gap-2">
                <span className="text-3xl font-bold tracking-tight text-emerald-700">
                  Healthy
                </span>
                <CheckCircle2 className="h-6 w-6 text-emerald-600" />
              </div>
              <p className="text-xs text-content-secondary mt-1">
                100% of verified transactions settled on schedule
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-border-subtle flex items-center justify-between text-xs text-content-secondary">
              <span>T+1 standard cycle</span>
              <span className="text-content-tertiary">RBI Escrow Active</span>
            </div>
          </Card>

          {/* Card 3: Held Amount */}
          <Card
            className={`p-6 border flex flex-col justify-between ${
              !isResolved
                ? 'border-amber-200 bg-amber-50/20'
                : 'border-emerald-200 bg-emerald-50/20'
            }`}
          >
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-content-tertiary">
                Held Amount
              </span>
              <div className="mt-2 text-3xl font-bold tracking-tight text-content-primary tabular-nums">
                {!isResolved ? '₹1,24,000' : '₹0'}
              </div>
              <p className="text-xs text-content-secondary mt-1">
                {!isResolved ? (
                  <span className="text-amber-800 font-medium">
                    Additional business verification required
                  </span>
                ) : (
                  <span className="text-emerald-700 font-medium">
                    Released! Scheduled for next batch
                  </span>
                )}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-border-subtle flex items-center justify-between text-xs">
              {!isResolved ? (
                <button
                  onClick={() => setVerificationModalOpen(true)}
                  className="text-xs font-semibold text-accent hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Resolve hold now</span>
                  <ArrowRight className="h-3 w-3" />
                </button>
              ) : (
                <span className="text-emerald-700 font-medium flex items-center gap-1">
                  <Check className="h-3.5 w-3.5" />
                  <span>Verification Complete</span>
                </span>
              )}
            </div>
          </Card>
        </div>

        {/* Interactive Hold Notice Card (If not resolved) */}
        {!isResolved ? (
          <SettlementCard
            hold={hold}
            onContinueVerification={() => setVerificationModalOpen(true)}
          />
        ) : (
          <Card className="p-6 border-emerald-200 bg-emerald-50/40 text-emerald-950 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                <Check className="h-5 w-5" strokeWidth={2.5} />
              </div>
              <div>
                <h4 className="text-sm font-semibold">
                  Settlement Verification Completed Successfully
                </h4>
                <p className="text-xs text-emerald-800 mt-0.5">
                  The hold on ₹1,24,000 has been lifted. Funds will be included in tomorrow morning's settlement.
                </p>
              </div>
            </div>
            <span className="text-xs font-semibold text-emerald-700 font-mono">
              STATUS: RELEASED
            </span>
          </Card>
        )}

        {/* Upcoming Settlements */}
        <div className="space-y-4">
          <div>
            <h3 className="text-base font-bold text-content-primary">Upcoming Settlements</h3>
            <p className="text-xs text-content-secondary mt-0.5">
              Scheduled payouts currently processing or queued
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {upcomingSettlements.map((settlement) => (
              <SettlementCard key={settlement.id} settlement={settlement} />
            ))}
          </div>
        </div>

        {/* Recent Settlements */}
        <div className="space-y-4">
          <div>
            <h3 className="text-base font-bold text-content-primary">Recent Settlements</h3>
            <p className="text-xs text-content-secondary mt-0.5">
              Successfully credited into your bank account with official UTR numbers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {recentSettlements.map((settlement) => (
              <SettlementCard key={settlement.id} settlement={settlement} />
            ))}
          </div>
        </div>
      </div>

      {/* Interactive Verification Modal (Scenario 3 Resolution Flow) */}
      {verificationModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs"
            onClick={() => setVerificationModalOpen(false)}
          />

          <div className="relative z-50 w-full max-w-lg bg-white rounded-2xl border border-border shadow-elevated p-6 space-y-6 animate-scale-in">
            <div className="flex items-center justify-between pb-3 border-b border-border-subtle">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-accent">
                  Compliance Resolution Flow
                </span>
                <h3 className="text-base font-semibold text-content-primary mt-0.5">
                  Release Settlement Hold (₹1,24,000)
                </h3>
              </div>
              <button
                onClick={() => setVerificationModalOpen(false)}
                className="p-1 rounded-lg text-content-tertiary hover:text-content-primary hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Step 1: Uploaded (Pre-completed) */}
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                  <div>
                    <span className="font-semibold text-emerald-950 block">
                      1. Upload recent invoices
                    </span>
                    <span className="text-emerald-700 text-[11px]">
                      3 purchase invoices verified
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-bold uppercase text-emerald-700">Done</span>
              </div>

              {/* Step 2: Confirm Activity */}
              <div className="p-3.5 rounded-xl bg-surface-primary border border-border-subtle space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-content-primary">
                    2. Confirm business activity
                  </span>
                  <input
                    type="checkbox"
                    id="step2"
                    checked={step2Confirmed}
                    onChange={(e) => setStep2Confirmed(e.target.checked)}
                    className="h-4 w-4 rounded accent-accent cursor-pointer"
                  />
                </div>
                <label
                  htmlFor="step2"
                  className="text-content-secondary text-[11px] block leading-relaxed cursor-pointer"
                >
                  I confirm that Acme Technologies operates as a B2B SaaS platform and recent
                  volume spikes correspond to legitimate commercial subscriptions.
                </label>
              </div>

              {/* Step 3: Complete verification */}
              <div className="p-3.5 rounded-xl bg-surface-primary border border-border-subtle space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-content-primary">
                    3. Sign compliance declaration
                  </span>
                  <input
                    type="checkbox"
                    id="step3"
                    disabled={!step2Confirmed}
                    checked={step3Signed}
                    onChange={(e) => setStep3Signed(e.target.checked)}
                    className="h-4 w-4 rounded accent-accent cursor-pointer disabled:opacity-30"
                  />
                </div>
                <label
                  htmlFor="step3"
                  className="text-content-secondary text-[11px] block leading-relaxed cursor-pointer"
                >
                  Authorize compliance release via Director electronic verification.
                </label>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setVerificationModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                disabled={!step2Confirmed || !step3Signed || isVerifying}
                onClick={handleCompleteVerification}
                className="gap-2"
              >
                {isVerifying ? (
                  <span>Verifying and releasing...</span>
                ) : (
                  <>
                    <span>Submit & Release ₹1,24,000</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </PageShell>
  );
}
