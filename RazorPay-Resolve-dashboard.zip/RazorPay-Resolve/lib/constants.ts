import {
  LayoutDashboard,
  AlertTriangle,
  ArrowRightLeft,
  Wallet,
  Activity,
  LifeBuoy,
  CheckCircle2,
  AlertCircle,
  Clock,
  RotateCcw,
  Search,
  Smartphone,
  CreditCard,
  Globe
} from 'lucide-react';
import { PaymentStatus, IssueSeverity, IssueCategory, PaymentMethod } from '@/data/types';

export const PAYMENT_STATUS_CONFIG: Record<PaymentStatus, { label: string; color: string; icon: any }> = {
  successful: { label: 'Successful', color: 'severity-success', icon: CheckCircle2 },
  failed: { label: 'Failed', color: 'severity-critical', icon: AlertCircle },
  pending: { label: 'Pending', color: 'severity-warning', icon: Clock },
  authorized: { label: 'Authorized', color: 'severity-info', icon: CheckCircle2 },
  refunded: { label: 'Refunded', color: 'text-content-secondary', icon: RotateCcw },
  disputed: { label: 'Disputed', color: 'severity-critical', icon: AlertTriangle },
  under_review: { label: 'Under Review', color: 'severity-warning', icon: Search },
};

export const ISSUE_SEVERITY_CONFIG: Record<IssueSeverity, { label: string; color: string; icon: any }> = {
  critical: { label: 'Critical', color: 'severity-critical', icon: AlertCircle },
  warning: { label: 'Warning', color: 'severity-warning', icon: AlertTriangle },
  info: { label: 'Info', color: 'severity-info', icon: Activity },
};

export const ISSUE_CATEGORY_CONFIG: Record<IssueCategory, { label: string }> = {
  payment: { label: 'Payments' },
  settlement: { label: 'Settlements' },
  account: { label: 'Account' },
  kyc: { label: 'KYC & Compliance' },
};

export const NAVIGATION_ITEMS = [
  { label: 'Overview', path: '/', icon: LayoutDashboard },
  { label: 'Payments', path: '/payments', icon: ArrowRightLeft },
  { label: 'Issues', path: '/issues', icon: AlertTriangle },
  { label: 'Settlements', path: '/settlements', icon: Wallet },
  { label: 'Account Health', path: '/account', icon: Activity },
  { label: 'Support', path: '/support', icon: LifeBuoy },
];

export const PAYMENT_METHOD_CONFIG: Record<PaymentMethod, { label: string; icon: any }> = {
  upi: { label: 'UPI', icon: Smartphone },
  card: { label: 'Card', icon: CreditCard },
  netbanking: { label: 'Netbanking', icon: Globe },
  wallet: { label: 'Wallet', icon: Wallet },
};

export const BANKS = [
  'HDFC Bank',
  'ICICI Bank',
  'State Bank of India',
  'Axis Bank',
  'Kotak Mahindra Bank',
  'Yes Bank',
  'Punjab National Bank',
  'Bank of Baroda'
];
