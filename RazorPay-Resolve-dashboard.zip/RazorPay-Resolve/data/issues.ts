import { Issue, IssueCategory } from '@/data/types';

export const issues: Issue[] = [
  {
    id: 'issue_001',
    category: 'payment',
    severity: 'critical',
    title: 'Customer charged, payment unresolved',
    description: 'A payment of ₹4,999 was debited from the customer but has not been confirmed in our system',
    explanation: "The customer's bank has confirmed the debit, but final confirmation has not reached Razorpay. This typically resolves within 30 minutes.",
    whatToDo: 'No action required. We are monitoring this automatically.',
    affectedAmount: 499900,
    affectedCount: 1,
    relatedPaymentIds: ['pay_8F92kLm4Tn9Qx2'],
    status: 'investigating',
    actionLabel: 'Inspect payment',
    actionHref: '/payments/pay_8F92kLm4Tn9Qx2',
    createdAt: '2026-09-05T10:00:00Z',
    updatedAt: '2026-09-05T10:30:00Z',
  },
  {
    id: 'issue_002',
    category: 'payment',
    severity: 'warning',
    isPattern: true,
    title: 'International payment failure spike',
    description: '38 international card payments have failed in the last 24 hours, affecting ₹1.84L in potential revenue',
    explanation: 'Most failures are from international Visa cards failing at the authentication step. This may be due to stricter 3DS enforcement by issuing banks.',
    whatToDo: 'Consider enabling alternative international payment methods or contacting affected customers with retry links.',
    affectedAmount: 18400000,
    affectedCount: 38,
    status: 'action_required',
    patternData: {
      causes: [
        { label: 'International card authentication failures', percentage: 42 },
        { label: 'Bank declines', percentage: 31 },
        { label: 'Insufficient funds', percentage: 18 },
        { label: 'Other', percentage: 9 },
      ],
      trend: 27,
      previousPeriod: 'previous 7 days',
    },
    recommendedAction: 'Enable additional payment methods for international customers',
    actionLabel: 'View affected payments',
    actionHref: '/issues/issue_002',
    createdAt: '2026-09-05T08:00:00Z',
    updatedAt: '2026-09-05T09:00:00Z',
  },
  {
    id: 'issue_003',
    category: 'settlement',
    severity: 'warning',
    title: 'Settlement review required',
    description: 'Your settlement of ₹1,24,000 is temporarily on hold pending additional verification',
    explanation: 'As part of periodic compliance checks, we need to verify some recent business activity. This is a standard process and your funds are safe.',
    whatToDo: 'Complete the 3-step verification process to release your settlement.',
    affectedAmount: 12400000,
    affectedCount: 1,
    status: 'action_required',
    recommendedAction: 'Complete verification',
    actionLabel: 'Continue verification',
    actionHref: '/settlements',
    createdAt: '2026-09-04T12:00:00Z',
    updatedAt: '2026-09-04T12:00:00Z',
  },
  {
    id: 'issue_004',
    category: 'kyc',
    severity: 'warning',
    title: 'Business verification incomplete',
    description: 'Your business verification could not be completed due to a document mismatch',
    explanation: 'The legal name on your uploaded document does not match your registered business name. This prevents full verification.',
    whatToDo: 'Upload a document that contains your exact registered business name: ABC Technologies Pvt Ltd.',
    affectedAmount: 0,
    affectedCount: 0,
    status: 'action_required',
    actionLabel: 'Fix verification',
    actionHref: '/account',
    createdAt: '2026-09-03T10:00:00Z',
    updatedAt: '2026-09-03T10:00:00Z',
  },
  {
    id: 'issue_005',
    category: 'payment',
    severity: 'critical',
    title: 'Customer charged but payment unresolved',
    description: 'A card payment of ₹12,499 was debited but has not been confirmed',
    explanation: "The customer's bank has confirmed the debit, but final confirmation has not reached Razorpay. This typically resolves within 30 minutes.",
    whatToDo: 'No action required. Automatic reconciliation in progress.',
    affectedAmount: 1249900,
    affectedCount: 1,
    relatedPaymentIds: ['pay_K2mN7pQ4Rl8Wx5'],
    status: 'investigating',
    actionLabel: 'Inspect payment',
    actionHref: '/payments/pay_K2mN7pQ4Rl8Wx5',
    createdAt: '2026-09-05T09:15:00Z',
    updatedAt: '2026-09-05T09:45:00Z',
  },
  {
    id: 'issue_006',
    category: 'payment',
    severity: 'info',
    title: 'HDFC netbanking latency elevated',
    description: 'HDFC Netbanking transactions are experiencing average confirmation delays of 45 seconds',
    explanation: 'HDFC core banking system is currently processing scheduled batch jobs. UPI and Card payments are completely unaffected.',
    whatToDo: 'Smart routing has automatically prioritized UPI rails for HDFC account holders.',
    affectedAmount: 8500000,
    affectedCount: 12,
    status: 'monitoring',
    actionLabel: 'View details',
    actionHref: '/issues/issue_006',
    createdAt: '2026-09-05T11:00:00Z',
    updatedAt: '2026-09-05T11:30:00Z',
  },
  {
    id: 'issue_007',
    category: 'settlement',
    severity: 'info',
    title: 'Previous settlement completed successfully',
    description: 'Settlement of ₹5,89,200 credited to HDFC Bank (****4892)',
    explanation: 'Funds have been credited with UTR HDFCR5202609040082194.',
    whatToDo: 'No action required.',
    affectedAmount: 58920000,
    affectedCount: 165,
    status: 'resolved',
    actionLabel: 'View settlement',
    actionHref: '/settlements',
    createdAt: '2026-09-04T06:15:00Z',
    updatedAt: '2026-09-04T06:15:00Z',
  },
];

export const getIssueById = (id: string): Issue | undefined => {
  return issues.find((issue) => issue.id === id);
};

export const getActiveIssues = (): Issue[] => {
  return issues.filter((issue) => issue.status !== 'resolved');
};

export const getCriticalIssues = (): Issue[] => {
  return issues.filter((issue) => issue.severity === 'critical');
};

export const getIssuesByCategory = (category: IssueCategory): Issue[] => {
  return issues.filter((issue) => issue.category === category);
};
