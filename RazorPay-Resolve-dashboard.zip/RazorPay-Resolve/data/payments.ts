import { Payment } from './types';

const now = Date.now();
const mins = (m: number) => new Date(now - m * 60000);
const hours = (h: number) => new Date(now - h * 3600000);

export const payments: Payment[] = [
  // 1. Core required pending UPI payment
  {
    id: 'pay_8F92kLm4Tn9Qx2',
    orderId: 'order_8F92kLm4T_1',
    amount: 499900,
    currency: 'INR',
    status: 'pending',
    method: 'upi',
    customer: { name: 'Rahul Sharma', email: 'rahul.sharma@example.com', phone: '+919876543210' },
    upi: { vpa: 'rahul@okicici' },
    bankName: 'ICICI Bank',
    timeline: [
      { id: 't1', title: 'Payment Initiated', description: 'Customer initiated payment', timestamp: mins(15), status: 'completed' },
      { id: 't2', title: 'Bank Authorized', description: 'Bank authorized the payment', timestamp: mins(14), status: 'completed' },
      { id: 't3', title: 'Razorpay Received', description: 'Razorpay system received update', timestamp: mins(13), status: 'completed' },
      { id: 't4', title: 'Awaiting Confirmation', description: 'Confirmation delayed from bank', timestamp: mins(2), status: 'current' }
    ],
    webhookDelivered: false,
    createdAt: mins(15),
    updatedAt: mins(2),
  },
  // 2. Core required under review intl card payment
  {
    id: 'pay_K2mN7pQ4Rl8Wx5',
    orderId: 'order_K2mN7pQ4R_2',
    amount: 1249900,
    currency: 'INR',
    status: 'under_review',
    method: 'card',
    customer: { name: 'John Anderson', email: 'john@example.com', phone: '+14155552671' },
    card: { network: 'visa', last4: '4242', issuer: 'Chase Bank', international: true },
    timeline: [
      { id: 't1', title: 'Payment Initiated', description: 'Customer initiated payment', timestamp: hours(2), status: 'completed' },
      { id: 't2', title: 'Bank Authorized', description: 'Bank authorized the payment', timestamp: hours(2), status: 'completed' },
      { id: 't3', title: 'Under Risk Review', description: 'Transaction flagged for manual review by risk team', timestamp: hours(1.9), status: 'current' }
    ],
    webhookDelivered: false,
    createdAt: hours(2),
    updatedAt: hours(1.9),
  },
  // 3. Failed international card payments (8+)
  {
    id: 'pay_Int1F', orderId: 'order_Int1F', amount: 299900, currency: 'INR', status: 'failed', method: 'card',
    customer: { name: 'Alice Smith', email: 'alice@example.com', phone: '+447911123456' },
    card: { network: 'visa', last4: '1111', issuer: 'Barclays', international: true },
    errorCode: 'BAD_REQUEST_ERROR', errorDescription: 'Authentication required but not completed',
    timeline: [{ id: 't1', title: 'Payment Failed', description: 'Authentication required', timestamp: hours(3), status: 'failed' }],
    webhookDelivered: true, createdAt: hours(3.1), updatedAt: hours(3)
  },
  {
    id: 'pay_Int2F', orderId: 'order_Int2F', amount: 459900, currency: 'INR', status: 'failed', method: 'card',
    customer: { name: 'Bob Jones', email: 'bob.j@example.com', phone: '+14155551234' },
    card: { network: 'visa', last4: '2222', issuer: 'Bank of America', international: true },
    errorCode: 'BAD_REQUEST_ERROR', errorDescription: 'Card issuer declined',
    timeline: [{ id: 't1', title: 'Payment Failed', description: 'Card issuer declined', timestamp: hours(4), status: 'failed' }],
    webhookDelivered: true, createdAt: hours(4.2), updatedAt: hours(4)
  },
  {
    id: 'pay_Int3F', orderId: 'order_Int3F', amount: 1599900, currency: 'INR', status: 'failed', method: 'card',
    customer: { name: 'Charlie Brown', email: 'cbrown@example.com', phone: '+12125557890' },
    card: { network: 'visa', last4: '3333', issuer: 'Wells Fargo', international: true },
    errorCode: 'BAD_REQUEST_ERROR', errorDescription: 'Insufficient funds',
    timeline: [{ id: 't1', title: 'Payment Failed', description: 'Insufficient funds', timestamp: hours(5), status: 'failed' }],
    webhookDelivered: true, createdAt: hours(5.5), updatedAt: hours(5)
  },
  {
    id: 'pay_Int4F', orderId: 'order_Int4F', amount: 349900, currency: 'INR', status: 'failed', method: 'card',
    customer: { name: 'Diana Prince', email: 'diana@example.com', phone: '+13105550000' },
    card: { network: 'visa', last4: '4444', issuer: 'Citibank', international: true },
    errorCode: 'BAD_REQUEST_ERROR', errorDescription: 'Authentication required but not completed',
    timeline: [{ id: 't1', title: 'Payment Failed', description: 'Authentication required', timestamp: hours(6), status: 'failed' }],
    webhookDelivered: true, createdAt: hours(6.1), updatedAt: hours(6)
  },
  {
    id: 'pay_Int5F', orderId: 'order_Int5F', amount: 599900, currency: 'INR', status: 'failed', method: 'card',
    customer: { name: 'Evan Wright', email: 'evan@example.com', phone: '+14155554321' },
    card: { network: 'visa', last4: '5555', issuer: 'Capital One', international: true },
    errorCode: 'BAD_REQUEST_ERROR', errorDescription: 'Card issuer declined',
    timeline: [{ id: 't1', title: 'Payment Failed', description: 'Card issuer declined', timestamp: hours(7), status: 'failed' }],
    webhookDelivered: true, createdAt: hours(7.2), updatedAt: hours(7)
  },
  {
    id: 'pay_Int6F', orderId: 'order_Int6F', amount: 899900, currency: 'INR', status: 'failed', method: 'card',
    customer: { name: 'Fiona Gallagher', email: 'fiona@example.com', phone: '+12125559876' },
    card: { network: 'visa', last4: '6666', issuer: 'HSBC', international: true },
    errorCode: 'BAD_REQUEST_ERROR', errorDescription: 'Authentication required but not completed',
    timeline: [{ id: 't1', title: 'Payment Failed', description: 'Authentication required', timestamp: hours(8), status: 'failed' }],
    webhookDelivered: true, createdAt: hours(8.5), updatedAt: hours(8)
  },
  {
    id: 'pay_Int7F', orderId: 'order_Int7F', amount: 1199900, currency: 'INR', status: 'failed', method: 'card',
    customer: { name: 'George Miller', email: 'george@example.com', phone: '+13105551111' },
    card: { network: 'visa', last4: '7777', issuer: 'US Bank', international: true },
    errorCode: 'BAD_REQUEST_ERROR', errorDescription: 'Card issuer declined',
    timeline: [{ id: 't1', title: 'Payment Failed', description: 'Card issuer declined', timestamp: hours(9), status: 'failed' }],
    webhookDelivered: true, createdAt: hours(9.1), updatedAt: hours(9)
  },
  {
    id: 'pay_Int8F', orderId: 'order_Int8F', amount: 1459900, currency: 'INR', status: 'failed', method: 'card',
    customer: { name: 'Hannah Abbott', email: 'hannah@example.com', phone: '+14155558888' },
    card: { network: 'visa', last4: '8888', issuer: 'Discover', international: true },
    errorCode: 'BAD_REQUEST_ERROR', errorDescription: 'Insufficient funds',
    timeline: [{ id: 't1', title: 'Payment Failed', description: 'Insufficient funds', timestamp: hours(10), status: 'failed' }],
    webhookDelivered: true, createdAt: hours(10.5), updatedAt: hours(10)
  },

  // 4. Successful payments (10+)
  ...Array.from({ length: 12 }).map((_, i) => ({
    id: `pay_Succ${i}`,
    orderId: `order_Succ${i}`,
    amount: [29900, 49900, 99900, 149900, 199900, 249900][i % 6],
    currency: 'INR' as const,
    status: 'successful' as const,
    method: i % 2 === 0 ? 'upi' as const : 'card' as const,
    customer: {
      name: ['Priya Patel', 'Arjun Mehta', 'Sneha Gupta', 'Vikram Singh', 'Anita Desai', 'Karan Johar'][i % 6],
      email: `customer${i}@example.in`,
      phone: `+9198765${43210 + i}`
    },
    ...(i % 2 === 0 ? { upi: { vpa: `customer${i}@oksbi` } } : { card: { network: 'mastercard' as const, last4: `${1000 + i}`, issuer: 'HDFC Bank', international: false } }),
    bankName: i % 2 === 0 ? 'State Bank of India' : 'HDFC Bank',
    timeline: [
      { id: 't1', title: 'Payment Initiated', description: 'Customer initiated', timestamp: mins(30 + i * 15), status: 'completed' as const },
      { id: 't2', title: 'Payment Successful', description: 'Amount captured', timestamp: mins(29 + i * 15), status: 'completed' as const }
    ],
    webhookDelivered: true,
    createdAt: mins(30 + i * 15),
    updatedAt: mins(29 + i * 15),
  })),

  // 5. Refunded payment
  {
    id: 'pay_Ref1X',
    orderId: 'order_Ref1X',
    amount: 500000,
    currency: 'INR',
    status: 'refunded',
    method: 'netbanking',
    customer: { name: 'Kavita Iyer', email: 'kavita@example.in', phone: '+919123456780' },
    bankName: 'Axis Bank',
    timeline: [
      { id: 't1', title: 'Payment Successful', description: 'Amount captured', timestamp: hours(48), status: 'completed' },
      { id: 't2', title: 'Refund Initiated', description: 'Merchant initiated refund', timestamp: hours(24), status: 'completed' },
      { id: 't3', title: 'Refund Processed', description: 'Refund sent to bank', timestamp: hours(23), status: 'completed' }
    ],
    webhookDelivered: true,
    createdAt: hours(48),
    updatedAt: hours(23),
  },

  // 6. Disputed payment
  {
    id: 'pay_Disp1Y',
    orderId: 'order_Disp1Y',
    amount: 850000,
    currency: 'INR',
    status: 'disputed',
    method: 'card',
    customer: { name: 'Manish Malhotra', email: 'manish@example.in', phone: '+919876500001' },
    card: { network: 'rupay', last4: '9999', issuer: 'Kotak Mahindra Bank', international: false },
    timeline: [
      { id: 't1', title: 'Payment Successful', description: 'Amount captured', timestamp: hours(72), status: 'completed' },
      { id: 't2', title: 'Dispute Raised', description: 'Customer disputed charge', timestamp: hours(12), status: 'completed' },
      { id: 't3', title: 'Awaiting Evidence', description: 'Merchant needs to provide evidence', timestamp: hours(12), status: 'current' }
    ],
    webhookDelivered: true,
    createdAt: hours(72),
    updatedAt: hours(12),
  }
];

export function getPaymentById(id: string): Payment | undefined {
  return payments.find(p => p.id === id);
}

export function getRecentPayments(count: number): Payment[] {
  return [...payments]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, count);
}

export function getFailedPayments(): Payment[] {
  return payments.filter(p => p.status === 'failed');
}

export function getPaymentsAtRisk(): Payment[] {
  return payments.filter(p => p.status === 'under_review' || p.status === 'pending' || p.status === 'disputed');
}
