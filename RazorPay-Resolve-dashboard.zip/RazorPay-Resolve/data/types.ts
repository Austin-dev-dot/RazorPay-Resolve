export type PaymentStatus =
  | 'successful'
  | 'failed'
  | 'pending'
  | 'authorized'
  | 'refunded'
  | 'disputed'
  | 'under_review';

export type PaymentMethod = 'upi' | 'card' | 'netbanking' | 'wallet';
export type CardNetwork = 'visa' | 'mastercard' | 'rupay' | 'amex';
export type IssueSeverity = 'critical' | 'warning' | 'info';
export type IssueCategory = 'payment' | 'settlement' | 'account' | 'kyc';
export type IssueStatus = 'investigating' | 'action_required' | 'monitoring' | 'resolved';
export type SettlementStatus = 'scheduled' | 'processing' | 'completed' | 'on_hold' | 'failed';
export type TimelineEventStatus = 'completed' | 'current' | 'pending' | 'failed';

export interface Customer {
  name: string;
  email: string;
  phone: string;
}

export interface CardDetails {
  network: CardNetwork;
  last4: string;
  issuer: string;
  international: boolean;
}

export interface UPIDetails {
  vpa: string;
}

export interface TimelineEvent {
  id: string;
  title: string;
  description: string;
  timestamp: string | Date;
  status: TimelineEventStatus;
  detail?: string;
}

export interface Payment {
  id: string;
  orderId: string;
  amount: number; // in paise
  currency: 'INR';
  status: PaymentStatus;
  method: PaymentMethod;
  customer: Customer;
  card?: CardDetails;
  upi?: UPIDetails;
  bankName?: string;
  bankStatus?: string;
  bankReferenceId?: string;
  timeline: TimelineEvent[];
  errorCode?: string;
  errorDescription?: string;
  webhookDelivered: boolean;
  webhookStatus?: string;
  fee?: number;
  tax?: number;
  settlementId?: string;
  createdAt: string | Date;
  updatedAt: string | Date;
}

export interface Issue {
  id: string;
  title: string;
  description: string;
  explanation: string;
  whatToDo: string;
  severity: IssueSeverity;
  category: IssueCategory;
  status: IssueStatus;
  affectedAmount: number;
  affectedCount: number;
  relatedPaymentIds?: string[];
  detectedAt?: string | Date;
  createdAt?: string | Date;
  updatedAt?: string | Date;
  recommendedAction?: string;
  actionLabel?: string;
  actionHref?: string;
  isPattern?: boolean;
  patternData?: {
    causes: { label: string; percentage: number }[];
    trend?: number; // % change vs previous period
    previousPeriod?: string;
  };
}

export interface Settlement {
  id: string;
  amount: number;
  utrNumber?: string;
  status: SettlementStatus;
  scheduledDate: string | Date;
  completedDate?: string | Date;
  bankAccount: string;
  paymentCount: number;
}

export interface SettlementStep {
  id: string;
  label: string;
  description: string;
  completed: boolean;
}

export interface SettlementHold {
  id: string;
  settlementId?: string;
  amount: number;
  reason: string;
  description: string;
  steps: SettlementStep[];
  createdAt: string | Date;
}

export interface AccountHealthCategory {
  label: string;
  score: number;
  description: string;
}

export interface AccountHealthWarning {
  id: string;
  message: string;
  severity: IssueSeverity;
  actionLabel?: string;
  actionHref?: string;
}

export interface AccountHealth {
  overallScore: number;
  categories: AccountHealthCategory[];
  warnings: AccountHealthWarning[];
}

export interface KYCIssue {
  id: string;
  title: string;
  description: string;
  reason: string;
  registeredValue: string;
  documentValue: string;
  mismatchField: string;
  howToFix: string;
  preservedFields: string[];
}

export interface AssistantAction {
  label: string;
  href?: string;
  onClick?: string;
  action?: string;
}

export interface AssistantMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string | Date;
  actions?: AssistantAction[];
  relatedPaymentId?: string;
}

export interface DiagnosticResult {
  paymentId: string;
  payment: Payment;
  diagnosis: string;
  bankStatus: string;
  razorpayStatus: string;
  webhookStatus: string;
  isAutoRecoverable: boolean;
  nextCheckIn: string;
  troubleshootingPerformed: string[];
}
