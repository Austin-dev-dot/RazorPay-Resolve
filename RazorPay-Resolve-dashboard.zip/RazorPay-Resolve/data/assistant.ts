import { AssistantMessage } from '@/data/types';

export const initialAssistantMessages: AssistantMessage[] = [
  {
    id: 'msg_welcome',
    role: 'assistant',
    content:
      "Hello. I'm Resolve Assistant. I monitor your live payment streams, webhook delivery, banking rails, and settlements. Ask me about any payment ID, failure spike, settlement hold, or compliance status.",
    timestamp: 'Just now',
    actions: [
      { label: 'Why did ₹7,499 fail?', action: 'query_fail_7499' },
      { label: 'Status of pay_8F92kL...?', action: 'query_mismatch' },
      { label: 'Why is ₹1.24L held?', action: 'query_settlement_hold' },
      { label: 'International decline spike', action: 'query_intl_spike' },
    ],
  },
];

const responses: Record<string, AssistantMessage> = {
  'why did this payment fail': {
    id: 'msg_fail_1',
    role: 'assistant',
    content:
      'The ₹7,499 payment from Rahul failed because the issuing bank declined the transaction. This is the 14th similar decline today. Most affected cards are international Visa cards failing at 3DS step-up authentication. I recommend enabling an alternative payment method for international customers.',
    timestamp: 'Just now',
    actions: [
      {
        label: 'Show affected payments',
        href: '/issues/issue_002',
      },
      {
        label: 'View recommendation',
        href: '/issues/issue_002',
      },
    ],
  },
  'customer paid but dashboard says failed': {
    id: 'msg_fail_2',
    role: 'assistant',
    content:
      'We found the transaction (Payment ID: pay_8F92kLm4Tn9Qx2). Customer Rahul Sharma was debited ₹4,999. The bank status is Successful (NPCI UTR received), but Razorpay is awaiting final callback confirmation. Webhook delivery was delayed due to an acquirer network timeout. Our automated reconciler is currently polling every 2 minutes. No customer action is required.',
    timestamp: 'Just now',
    actions: [
      {
        label: 'View payment details',
        href: '/payments/pay_8F92kLm4Tn9Qx2',
      },
      {
        label: 'Trace bank timeline',
        href: '/payments/pay_8F92kLm4Tn9Qx2',
      },
    ],
    relatedPaymentId: 'pay_8F92kLm4Tn9Qx2',
  },
  'settlement delayed': {
    id: 'msg_settlement_1',
    role: 'assistant',
    content:
      'Your settlement of ₹1,24,000 scheduled for Sep 4 is temporarily on hold pending periodic business verification. 1 of 3 verification steps is already completed (invoices uploaded). You need to confirm your business activity to release the remaining funds.',
    timestamp: 'Just now',
    actions: [
      {
        label: 'Continue verification',
        href: '/settlements',
      },
      {
        label: 'View settlement breakdown',
        href: '/settlements',
      },
    ],
  },
  'international payments failing': {
    id: 'msg_intl_1',
    role: 'assistant',
    content:
      'We detected an international failure spike affecting 38 payments totaling ₹1.84L in the last 24 hours (up 27% compared to the previous 7 days). 42% are due to card authentication timeouts, 31% bank declines, and 18% insufficient funds. Most affected cards are non-3DS international Visa cards.',
    timestamp: 'Just now',
    actions: [
      {
        label: 'Inspect failure intelligence',
        href: '/issues/issue_002',
      },
      {
        label: 'View 38 affected payments',
        href: '/payments?filter=failed_intl',
      },
    ],
  },
  'kyc mismatch': {
    id: 'msg_kyc_1',
    role: 'assistant',
    content:
      'Your business verification flagged a discrepancy: your uploaded Certificate of Incorporation specifies "ABC Technology", whereas your Razorpay account is registered as "ABC Technologies Pvt Ltd". All other 5 documents (PAN, GST, Bank) are already verified and safely preserved.',
    timestamp: 'Just now',
    actions: [
      {
        label: 'Fix document mismatch',
        href: '/account',
      },
    ],
  },
};

export const getAssistantResponse = (query: string): AssistantMessage => {
  const normalizedQuery = query.toLowerCase().trim();

  if (
    normalizedQuery.includes('why did this payment fail') ||
    normalizedQuery.includes('7,499') ||
    normalizedQuery.includes('rahul') ||
    normalizedQuery.includes('query_fail_7499')
  ) {
    return { ...responses['why did this payment fail'], id: `resp_${Date.now()}` };
  }

  if (
    normalizedQuery.includes('customer paid') ||
    normalizedQuery.includes('mismatch') ||
    normalizedQuery.includes('pay_8f92') ||
    normalizedQuery.includes('query_mismatch') ||
    normalizedQuery.includes('dashboard says failed') ||
    normalizedQuery.includes('unresolved')
  ) {
    return { ...responses['customer paid but dashboard says failed'], id: `resp_${Date.now()}` };
  }

  if (
    normalizedQuery.includes('settlement') ||
    normalizedQuery.includes('1.24') ||
    normalizedQuery.includes('hold') ||
    normalizedQuery.includes('delayed') ||
    normalizedQuery.includes('query_settlement_hold')
  ) {
    return { ...responses['settlement delayed'], id: `resp_${Date.now()}` };
  }

  if (
    normalizedQuery.includes('international') ||
    normalizedQuery.includes('spike') ||
    normalizedQuery.includes('visa') ||
    normalizedQuery.includes('query_intl_spike')
  ) {
    return { ...responses['international payments failing'], id: `resp_${Date.now()}` };
  }

  if (
    normalizedQuery.includes('kyc') ||
    normalizedQuery.includes('verification') ||
    normalizedQuery.includes('name mismatch')
  ) {
    return { ...responses['kyc mismatch'], id: `resp_${Date.now()}` };
  }

  // Fallback respecting instruction:
  // "Never invent transaction information. If information isn't available, clearly say:
  // 'I don't have enough information to determine the cause yet'"
  return {
    id: `resp_${Date.now()}`,
    role: 'assistant',
    content:
      "I don't have enough diagnostic information to determine the cause yet for that specific query. Would you like me to inspect your latest payment logs, or diagnose a specific Payment ID or Settlement ID?",
    timestamp: 'Just now',
    actions: [
      { label: 'Diagnose a Payment ID', href: '/support' },
      { label: 'View active issues', href: '/issues' },
    ],
  };
};
