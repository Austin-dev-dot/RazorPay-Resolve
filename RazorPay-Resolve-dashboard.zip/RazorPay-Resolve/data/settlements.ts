import { Settlement, SettlementHold } from '@/data/types';

export const settlements: Settlement[] = [
  {
    id: 'set_9K2L1M4N',
    amount: 48240000, // ₹4,82,400
    status: 'scheduled',
    scheduledDate: 'Tomorrow, 6:00 AM',
    bankAccount: 'HDFC Bank (****4892)',
    paymentCount: 142,
  },
  {
    id: 'set_1A2B3C4D',
    amount: 12400000, // ₹1,24,000
    status: 'on_hold',
    scheduledDate: 'Paused on Sep 4',
    bankAccount: 'HDFC Bank (****4892)',
    paymentCount: 18,
  },
  {
    id: 'set_4D5E6F7G',
    amount: 31250000, // ₹3,12,500
    status: 'processing',
    scheduledDate: 'Today, 6:00 PM',
    bankAccount: 'HDFC Bank (****4892)',
    paymentCount: 98,
  },
  {
    id: 'set_7G8H9I0J',
    amount: 58920000, // ₹5,89,200
    status: 'completed',
    scheduledDate: 'Yesterday',
    completedDate: 'Sep 4, 2026, 6:15 AM',
    utrNumber: 'HDFCR5202609040082194',
    bankAccount: 'HDFC Bank (****4892)',
    paymentCount: 165,
  },
  {
    id: 'set_K0L1M2N3',
    amount: 42100000, // ₹4,21,000
    status: 'completed',
    scheduledDate: 'Sep 3, 2026',
    completedDate: 'Sep 3, 2026, 6:12 AM',
    utrNumber: 'HDFCR5202609030074312',
    bankAccount: 'HDFC Bank (****4892)',
    paymentCount: 128,
  },
  {
    id: 'set_P4Q5R6S7',
    amount: 67450000, // ₹6,74,500
    status: 'completed',
    scheduledDate: 'Sep 2, 2026',
    completedDate: 'Sep 2, 2026, 6:18 AM',
    utrNumber: 'HDFCR5202609020063920',
    bankAccount: 'HDFC Bank (****4892)',
    paymentCount: 210,
  },
];

export const settlementHold: SettlementHold = {
  id: 'hold_001',
  settlementId: 'set_1A2B3C4D',
  amount: 12400000, // ₹1,24,000
  reason: 'Additional business verification required',
  description:
    'As part of our periodic regulatory compliance review, we require verification of recent commercial invoicing to resume automated settlements. Your funds are secured in your nodal account.',
  steps: [
    {
      id: 'step_1',
      label: 'Upload recent invoices',
      description: 'Submit 3 recent customer purchase invoices or service agreements',
      completed: true,
    },
    {
      id: 'step_2',
      label: 'Confirm business activity',
      description: 'Confirm that your current primary business activity matches your registered category',
      completed: false,
    },
    {
      id: 'step_3',
      label: 'Complete verification',
      description: 'Digitally sign compliance declaration via Aadhaar e-Sign or Director OTP',
      completed: false,
    },
  ],
  createdAt: '2026-09-04T10:30:00Z',
};

export const getNextSettlement = (): Settlement | undefined => {
  return settlements.find((s) => s.id === 'set_9K2L1M4N') || settlements[0];
};

export const getUpcomingSettlements = (): Settlement[] => {
  return settlements.filter((s) => ['scheduled', 'processing'].includes(s.status));
};

export const getRecentSettlements = (): Settlement[] => {
  return settlements.filter((s) => s.status === 'completed');
};
