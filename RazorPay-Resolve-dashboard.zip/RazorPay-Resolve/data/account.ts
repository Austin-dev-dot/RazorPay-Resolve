import { AccountHealth, KYCIssue } from '@/data/types';

export const accountHealth: AccountHealth = {
  overallScore: 92,
  categories: [
    {
      label: 'Payment reliability',
      score: 96,
      description: '98.2% transaction success rate over last 30 days',
    },
    {
      label: 'Verification status',
      score: 100,
      description: 'Business identity and bank account verified',
    },
    {
      label: 'Chargeback risk',
      score: 88,
      description: 'Slightly elevated due to 2 recent customer disputes',
    },
    {
      label: 'Settlement health',
      score: 94,
      description: 'Daily settlements active, one compliance review pending',
    },
  ],
  warnings: [
    {
      id: 'warn_1',
      message: 'International payment failures have increased 18% this week',
      severity: 'warning',
      actionLabel: 'View pattern',
      actionHref: '/issues/issue_002',
    },
    {
      id: 'warn_2',
      message: 'Your business verification expires in 24 days',
      severity: 'info',
      actionLabel: 'Review',
      actionHref: '/account#verification',
    },
  ],
};

export const kycIssue: KYCIssue = {
  id: 'kyc_001',
  title: 'Verification needs attention',
  description: "Your business verification couldn't be completed",
  reason: "The legal name on your uploaded document doesn't match your registered business name",
  registeredValue: 'ABC Technologies Pvt Ltd',
  documentValue: 'ABC Technology',
  mismatchField: 'Legal Business Name',
  howToFix: 'Upload a document containing: ABC Technologies Pvt Ltd',
  preservedFields: [
    'PAN Number (ABCDE1234F)',
    'GST Number (29ABCDE1234F1Z5)',
    'HDFC Current Account (****4892)',
    'Registered Address (Bangalore, KA)',
    'Director Identification (2 Directors)',
  ],
};
