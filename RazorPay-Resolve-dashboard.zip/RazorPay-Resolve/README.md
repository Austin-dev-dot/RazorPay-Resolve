# Razorpay Resolve

Razorpay Resolve is a responsive Next.js dashboard prototype for exploring payment health, transaction issues, settlements, account/KYC status, and guided support diagnostics.

The app is self-contained: it renders realistic **mock data** from `data/` and does not require a Razorpay API key, database, or environment variables to start.

## Prerequisites

- Node.js 18.17 or later
- npm 9 or later

## Run locally

```bash
git clone https://github.com/Austin-dev-dot/RazorPay-Resolve.git
cd RazorPay-Resolve
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Production check

```bash
npm run build
npm run start
```

## Available commands

| Command | Purpose |
| --- | --- |
| `npm run dev` | Start the local development server |
| `npm run build` | Create a production build |
| `npm run start` | Serve the production build |
| `npm run lint` | Run Next.js linting |
| `npm run typecheck` | Validate TypeScript without emitting files |

## Project structure

- `app/` — dashboard routes and global styles
- `components/` — reusable UI, layout, payment, resolution, search, and assistant components
- `data/` — local mock payments, issues, settlements, account, and assistant data
- `lib/` — shared utilities and constants

## Note

This repository is a front-end prototype. The sample payment and customer records are fictitious; replace the modules in `data/` with authenticated server-side integrations before using it with real merchant data.
