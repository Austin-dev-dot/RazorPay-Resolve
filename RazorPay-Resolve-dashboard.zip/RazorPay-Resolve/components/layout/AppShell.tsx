'use client';

import * as React from 'react';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { CommandSearch } from '@/components/search/CommandSearch';
import { AssistantPanel } from '@/components/assistant/AssistantPanel';

interface AppShellProps {
  children: React.ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const [searchOpen, setSearchOpen] = React.useState(false);
  const [assistantOpen, setAssistantOpen] = React.useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <div className="min-h-screen flex bg-surface-primary font-sans text-content-primary">
      {/* Desktop Sidebar */}
      <div className="hidden md:block">
        <Sidebar onOpenAssistant={() => setAssistantOpen(true)} />
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative z-50 w-[15.5rem] bg-surface-secondary h-full shadow-elevated">
            <Sidebar
              onOpenAssistant={() => {
                setMobileMenuOpen(false);
                setAssistantOpen(true);
              }}
            />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          onOpenSearch={() => setSearchOpen(true)}
          onOpenAssistant={() => setAssistantOpen(true)}
          onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
        />

        <main className="flex-1 p-5 md:p-8 lg:p-10 max-w-[1440px] w-full mx-auto animate-fade-in">
          {children}
        </main>
      </div>

      {/* Global Command Palette (⌘K) */}
      <CommandSearch open={searchOpen} onOpenChange={setSearchOpen} />

      {/* Resolve Assistant Slide-over Drawer */}
      <AssistantPanel isOpen={assistantOpen} onClose={() => setAssistantOpen(false)} />
    </div>
  );
}
