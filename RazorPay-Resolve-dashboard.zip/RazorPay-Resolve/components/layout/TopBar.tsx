'use client';

import * as React from 'react';
import {
  Search,
  Sparkles,
  Menu,
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { ThemeToggle } from './ThemeToggle';

interface TopBarProps {
  onOpenSearch: () => void;
  onOpenAssistant: () => void;
  onToggleMobileMenu?: () => void;
}

export function TopBar({
  onOpenSearch,
  onOpenAssistant,
  onToggleMobileMenu,
}: TopBarProps) {
  return (
    <header className="h-[4.25rem] border-b border-border bg-white/95 backdrop-blur-xl px-5 md:px-8 flex items-center justify-between sticky top-0 z-30">
      <div className="flex items-center gap-4">
        {onToggleMobileMenu && (
          <button
            onClick={onToggleMobileMenu}
            className="md:hidden p-2 text-content-secondary hover:text-content-primary rounded-lg hover:bg-slate-200/70"
          >
            <Menu className="h-5 w-5" />
          </button>
        )}

        {/* Global Search Trigger (⌘K) */}
        <button
          onClick={onOpenSearch}
          className="flex items-center gap-3 px-3.5 py-2 rounded-lg bg-surface-secondary border border-border-subtle hover:border-rzp-blue/40 text-xs text-content-secondary transition-all w-64 md:w-80 group cursor-pointer"
        >
          <Search className="h-3.5 w-3.5 text-content-tertiary group-hover:text-content-primary transition-colors" />
          <span className="flex-1 text-left truncate">
            Search a payment, customer, or issue...
          </span>
          <kbd className="hidden sm:inline-flex items-center gap-0.5 rounded-md bg-surface-tertiary px-1.5 py-0.5 text-[10px] font-medium text-content-tertiary border border-border-subtle">
            ⌘K
          </kbd>
        </button>
      </div>

      <div className="flex items-center gap-3.5">
        {/* System Health Status Indicator */}
        <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-full bg-surface-secondary border border-border-subtle text-xs text-content-secondary">
          <span className="h-1.5 w-1.5 rounded-full bg-content-primary" />
          <span>Systems normal</span>
          <span className="text-content-tertiary">·</span>
          <span className="tabular-nums font-mono text-[11px] text-content-tertiary">
            Sync: 1m ago
          </span>
        </div>

        <ThemeToggle />

        {/* Resolve Assistant trigger button */}
        <Button
          variant="glass"
          size="sm"
          onClick={onOpenAssistant}
          className="gap-2 text-xs font-semibold cursor-pointer"
        >
          <Sparkles className="h-3.5 w-3.5 text-rzp-blue" />
          <span className="hidden sm:inline">Ask Resolve</span>
        </Button>
      </div>
    </header>
  );
}
