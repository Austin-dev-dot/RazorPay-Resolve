'use client';

import * as React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  ArrowRightLeft,
  AlertTriangle,
  Wallet,
  Activity,
  LifeBuoy,
  ShieldCheck,
  ChevronRight,
  Sparkles,
  Send,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { issues } from '@/data/issues';

interface SidebarProps {
  onOpenAssistant?: () => void;
}

export function Sidebar({ onOpenAssistant }: SidebarProps) {
  const pathname = usePathname();
  const activeIssuesCount = issues.filter((issue) => issue.status === 'action_required').length;

  const navItems = [
    { label: 'Overview', path: '/', icon: LayoutDashboard },
    { label: 'Payments', path: '/payments', icon: ArrowRightLeft },
    { label: 'Payouts', path: '/payouts', icon: Send },
    {
      label: 'Action Center',
      path: '/issues',
      icon: AlertTriangle,
      badge: activeIssuesCount > 0 ? `${activeIssuesCount}` : undefined,
      badgeColor: 'bg-surface-tertiary text-content-primary border-border',
    },
    { label: 'Settlements', path: '/settlements', icon: Wallet },
    { label: 'Account Health', path: '/account', icon: Activity },
    { label: 'Resolve Help', path: '/support', icon: LifeBuoy },
  ];

  return (
    <aside className="w-[15.5rem] shrink-0 border-r border-border bg-white flex flex-col justify-between min-h-screen sticky top-0 h-screen select-none">
      <div>
        {/* Brand header */}
        <div className="p-5.5 px-6 border-b border-border-subtle">
          <Link href="/" className="block group">
            <div className="flex items-center gap-2.5">
              <div className="h-8 w-8 rounded-md bg-rzp-blue text-white flex items-center justify-center font-bold tracking-tighter text-sm shadow-sm">
                R
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-sm text-content-primary">
                    Razorpay
                  </span>
                  <span className="text-[10px] font-semibold text-rzp-blue px-1.5 py-0.5 rounded-md bg-rzp-blue-light border border-rzp-blue/10">
                    Resolve
                  </span>
                </div>
                <span className="text-[11px] text-content-tertiary block font-normal leading-tight">
                  Resolution Layer
                </span>
              </div>
            </div>
          </Link>
        </div>

        {/* Navigation list */}
        <nav className="p-4 pt-5 space-y-1">
          <div className="px-3 pb-2 text-[10px] font-bold text-content-tertiary uppercase tracking-wider">
            Workspace
          </div>

          {navItems.map((item) => {
            const isActive =
              item.path === '/'
                ? pathname === '/'
                : pathname.startsWith(item.path);
            const Icon = item.icon;

            return (
              <Link
                key={item.path}
                href={item.path}
                className={cn(
                  'flex items-center justify-between px-3 py-2.5 rounded-[10px] text-xs font-medium transition-all group',
                  isActive
                    ? 'bg-rzp-blue-light text-rzp-blue font-semibold'
                    : 'text-content-secondary hover:text-content-primary hover:bg-rzp-blue-light/60'
                )}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={cn(
                      'h-4 w-4 transition-colors',
                      isActive
                        ? 'text-rzp-blue'
                        : 'text-content-tertiary group-hover:text-content-secondary'
                    )}
                    strokeWidth={1.75}
                  />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={cn(
                      'text-[10px] font-bold px-2 py-0.25 rounded-full border',
                      item.badgeColor || 'bg-slate-100 text-slate-700'
                    )}
                  >
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
      </div>

      {/* Resolve Assistant Proactive Banner & Merchant Card */}
      <div className="p-4 space-y-3 border-t border-border-subtle bg-surface-primary/50">
        {onOpenAssistant && (
          <button
            onClick={onOpenAssistant}
            className="w-full p-3.5 rounded-xl bg-rzp-blue-subtle border border-rzp-blue/10 hover:border-rzp-blue/30 transition-all text-left group cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-rzp-blue" />
                <span className="text-xs font-semibold text-content-primary">
                  Ask Resolve
                </span>
              </div>
              <ChevronRight className="h-3.5 w-3.5 text-rzp-blue group-hover:translate-x-0.5 transition-transform" />
            </div>
            <p className="text-[11px] text-content-secondary mt-1 leading-snug">
              Get a plain-language answer about any payment or settlement
            </p>
          </button>
        )}

        {/* Merchant profile footer */}
        <div className="p-3 rounded-xl bg-white border border-border-subtle flex items-center justify-between">
          <div className="min-w-0">
            <div className="text-xs font-semibold text-content-primary truncate">
              Acme Technologies
            </div>
            <div className="text-[11px] text-content-tertiary font-mono truncate">
              MID: acme_89210
            </div>
          </div>
          <div
            className="h-2 w-2 rounded-full bg-content-primary shrink-0"
            title="Gateway Live Connected"
          />
        </div>
      </div>
    </aside>
  );
}
