import * as React from 'react';
import { cn } from '@/lib/utils';

interface PageShellProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

export function PageShell({
  title,
  subtitle,
  badge,
  actions,
  children,
  className,
}: PageShellProps) {
  return (
    <div className={cn('space-y-8', className)}>
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-4 pb-5 border-b border-border-subtle/80">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl md:text-[2rem] font-bold tracking-tight text-content-primary">
              {title}
            </h1>
            {badge}
          </div>
          {subtitle && (
            <p className="text-xs md:text-sm text-content-secondary mt-1 max-w-2xl leading-relaxed">
              {subtitle}
            </p>
          )}
        </div>

        {actions && <div className="flex items-center gap-3 shrink-0">{actions}</div>}
      </div>

      {/* Page Body */}
      <div>{children}</div>
    </div>
  );
}
