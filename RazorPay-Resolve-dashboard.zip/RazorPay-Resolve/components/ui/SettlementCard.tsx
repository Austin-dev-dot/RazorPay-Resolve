'use client';

import * as React from 'react';
import {
  Wallet,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ExternalLink,
  ShieldCheck,
  Building2,
} from 'lucide-react';
import { Settlement, SettlementHold } from '@/data/types';
import { formatCurrency } from '@/lib/utils';
import { Card } from './Card';
import { Button } from './Button';
import { ProgressSteps } from './ProgressSteps';

interface SettlementCardProps {
  settlement?: Settlement;
  hold?: SettlementHold;
  onContinueVerification?: () => void;
  className?: string;
}

export function SettlementCard({
  settlement,
  hold,
  onContinueVerification,
  className,
}: SettlementCardProps) {
  if (hold) {
    const completedCount = hold.steps.filter((s) => s.completed).length;

    return (
      <Card className="p-6 md:p-8 border-amber-200 bg-gradient-to-br from-amber-50/40 via-white to-orange-50/20 shadow-card">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-6 border-b border-amber-200/60">
          <div className="flex items-start gap-3.5">
            <div className="h-9 w-9 rounded-xl bg-amber-100 text-amber-800 border border-amber-200 flex items-center justify-center shrink-0 mt-0.5">
              <AlertTriangle className="h-5 w-5" strokeWidth={1.75} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
                  Settlement Temporarily Paused
                </span>
                <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200">
                  Verification hold
                </span>
              </div>
              <h3 className="text-2xl font-bold tracking-tight text-content-primary mt-1 tabular-nums">
                {formatCurrency(hold.amount)}
              </h3>
              <p className="text-xs text-content-secondary mt-1">
                Reason: <strong className="text-content-primary">{hold.reason}</strong>
              </p>
            </div>
          </div>

          <div className="shrink-0">
            <Button
              variant="primary"
              size="md"
              onClick={onContinueVerification}
              className="gap-2 w-full md:w-auto cursor-pointer"
            >
              <span>Continue verification</span>
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* What you need to do + Progress Steps */}
        <div className="mt-6">
          <div className="mb-4">
            <span className="text-xs font-bold uppercase tracking-wider text-content-tertiary">
              What you need to do
            </span>
            <p className="text-xs text-content-secondary mt-0.5">
              Follow these simple verification steps to resume normal T+1 settlement cycles.
            </p>
          </div>

          <ProgressSteps steps={hold.steps} currentStepIndex={1} />
        </div>

        <div className="mt-6 pt-4 border-t border-amber-200/60 flex items-center justify-between text-xs text-content-secondary">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="h-4 w-4 text-emerald-600" />
            <span>Funds remain 100% secure in RBI-authorized nodal escrow.</span>
          </div>
          <span className="text-[11px] font-mono text-content-tertiary">ID: {hold.id}</span>
        </div>
      </Card>
    );
  }

  if (!settlement) return null;

  const isCompleted = settlement.status === 'completed';
  const isScheduled = settlement.status === 'scheduled';
  const isProcessing = settlement.status === 'processing';

  return (
    <Card className="p-6 border-border hover:shadow-card-hover transition-all">
      <div className="flex items-start justify-between gap-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-content-tertiary">
            {isScheduled ? 'Scheduled Settlement' : isCompleted ? 'Completed Settlement' : 'In Processing'}
          </span>
          <div className="mt-1 text-2xl font-bold text-content-primary tabular-nums">
            {formatCurrency(settlement.amount)}
          </div>
        </div>

        <div className="text-right">
          <span
            className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-0.5 rounded-full border ${
              isCompleted
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : isScheduled
                ? 'bg-blue-50 text-blue-700 border-blue-200'
                : 'bg-amber-50 text-amber-800 border-amber-200'
            }`}
          >
            {isCompleted && <CheckCircle2 className="h-3 w-3" />}
            {isScheduled && <Clock className="h-3 w-3" />}
            <span>{settlement.status.replace('_', ' ')}</span>
          </span>
        </div>
      </div>

      <div className="mt-4 pt-3 border-t border-border-subtle grid grid-cols-2 gap-2 text-xs">
        <div>
          <span className="text-content-tertiary block text-[10px] uppercase">Bank Account</span>
          <span className="text-content-primary font-medium">{settlement.bankAccount}</span>
        </div>

        <div>
          <span className="text-content-tertiary block text-[10px] uppercase">
            {isCompleted ? 'Credited At' : 'Expected'}
          </span>
          <span className="text-content-primary font-medium">
            {String(settlement.completedDate || settlement.scheduledDate)}
          </span>
        </div>
      </div>

      {settlement.utrNumber && (
        <div className="mt-3 pt-2 border-t border-border-subtle flex items-center justify-between text-[11px]">
          <span className="text-content-tertiary">UTR Number:</span>
          <span className="font-mono text-content-primary font-medium">{settlement.utrNumber}</span>
        </div>
      )}
    </Card>
  );
}
