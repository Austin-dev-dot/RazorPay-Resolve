import * as React from 'react';
import { CheckCircle2, ShieldCheck, LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from './Button';

interface EmptyStateProps {
  title?: string;
  description?: string;
  icon?: LucideIcon;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export function EmptyState({
  title = 'All clear',
  description = 'No payment issues need your attention. Your payments are running normally.',
  icon: Icon = CheckCircle2,
  actionLabel,
  onAction,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        'rounded-2xl border border-dashed border-border bg-white/50 p-12 text-center flex flex-col items-center justify-center max-w-lg mx-auto',
        className
      )}
    >
      <div className="h-12 w-12 rounded-2xl bg-surface-tertiary text-content-primary border border-border-subtle flex items-center justify-center mb-4">
        <Icon className="h-6 w-6" strokeWidth={1.75} />
      </div>

      <h3 className="text-base font-semibold text-content-primary tracking-tight">{title}</h3>
      <p className="text-sm text-content-secondary mt-1.5 max-w-md leading-relaxed">
        {description}
      </p>

      {actionLabel && onAction && (
        <Button variant="secondary" size="sm" onClick={onAction} className="mt-5">
          {actionLabel}
        </Button>
      )}
    </div>
  );
}
