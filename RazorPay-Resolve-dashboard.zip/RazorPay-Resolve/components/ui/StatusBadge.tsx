import * as React from 'react';
import { cn } from '@/lib/utils';
import { PaymentStatus, IssueSeverity, IssueStatus } from '@/data/types';

interface StatusBadgeProps {
  status?: PaymentStatus;
  severity?: IssueSeverity;
  issueStatus?: IssueStatus;
  customLabel?: string;
  size?: 'sm' | 'md' | 'lg';
  showDot?: boolean;
  className?: string;
}

const neutralStatus = 'bg-surface-tertiary text-content-secondary border-border-subtle';

const paymentStatusConfig: Record<
  PaymentStatus,
  { label: string; dotClass: string; badgeClass: string }
> = {
  successful: {
    label: 'Successful',
    dotClass: 'bg-content-primary',
    badgeClass: neutralStatus,
  },
  failed: {
    label: 'Failed',
    dotClass: 'bg-content-primary',
    badgeClass: neutralStatus,
  },
  pending: {
    label: 'Awaiting confirmation',
    dotClass: 'bg-content-secondary',
    badgeClass: neutralStatus,
  },
  authorized: {
    label: 'Authorized',
    dotClass: 'bg-content-secondary',
    badgeClass: neutralStatus,
  },
  refunded: {
    label: 'Refunded',
    dotClass: 'bg-content-tertiary',
    badgeClass: neutralStatus,
  },
  disputed: {
    label: 'Disputed',
    dotClass: 'bg-content-secondary',
    badgeClass: neutralStatus,
  },
  under_review: {
    label: 'Needs attention',
    dotClass: 'bg-content-secondary',
    badgeClass: neutralStatus,
  },
};

const severityConfig: Record<
  IssueSeverity,
  { label: string; dotClass: string; badgeClass: string }
> = {
  critical: {
    label: 'Action Required',
    dotClass: 'bg-content-primary',
    badgeClass: neutralStatus,
  },
  warning: {
    label: 'Needs attention',
    dotClass: 'bg-content-secondary',
    badgeClass: neutralStatus,
  },
  info: {
    label: 'Monitoring',
    dotClass: 'bg-content-secondary',
    badgeClass: neutralStatus,
  },
};

const issueStatusConfig: Record<
  IssueStatus,
  { label: string; dotClass: string; badgeClass: string }
> = {
  investigating: {
    label: 'Reconciliation in progress',
    dotClass: 'bg-content-secondary',
    badgeClass: neutralStatus,
  },
  action_required: {
    label: 'Action required',
    dotClass: 'bg-content-primary',
    badgeClass: neutralStatus,
  },
  monitoring: {
    label: 'Monitoring logs',
    dotClass: 'bg-content-secondary',
    badgeClass: neutralStatus,
  },
  resolved: {
    label: 'Settled / Resolved',
    dotClass: 'bg-content-primary',
    badgeClass: neutralStatus,
  },
};

export function StatusBadge({
  status,
  severity,
  issueStatus,
  customLabel,
  size = 'md',
  showDot = true,
  className,
}: StatusBadgeProps) {
  let label = customLabel || '';
  let dotClass = 'bg-content-tertiary';
  let badgeClass = neutralStatus;

  if (status && paymentStatusConfig[status]) {
    const config = paymentStatusConfig[status];
    label = customLabel || config.label;
    dotClass = config.dotClass;
    badgeClass = config.badgeClass;
  } else if (severity && severityConfig[severity]) {
    const config = severityConfig[severity];
    label = customLabel || config.label;
    dotClass = config.dotClass;
    badgeClass = config.badgeClass;
  } else if (issueStatus && issueStatusConfig[issueStatus]) {
    const config = issueStatusConfig[issueStatus];
    label = customLabel || config.label;
    dotClass = config.dotClass;
    badgeClass = config.badgeClass;
  }

  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5 gap-1.5',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3 py-1.5 gap-2',
  };

  const dotSizes = {
    sm: 'h-1.5 w-1.5',
    md: 'h-2 w-2',
    lg: 'h-2.5 w-2.5',
  };

  return (
    <span
      className={cn(
        'inline-flex items-center font-medium rounded-full border select-none transition-colors tracking-tight',
        sizeClasses[size],
        badgeClass,
        className
      )}
    >
      {showDot && (
        <span
          className={cn('rounded-full shrink-0', dotSizes[size], dotClass)}
          aria-hidden="true"
        />
      )}
      <span>{label}</span>
    </span>
  );
}
