import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const badgeVariants = cva(
  'inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium transition-colors select-none',
  {
    variants: {
      variant: {
        default: 'bg-slate-100 text-content-primary border border-border-subtle',
        secondary: 'bg-surface-tertiary text-content-secondary',
        outline: 'border border-border text-content-primary',
        critical: 'bg-severity-critical-bg text-severity-critical border border-severity-critical-border',
        warning: 'bg-severity-warning-bg text-severity-warning border border-severity-warning-border',
        success: 'bg-severity-success-bg text-severity-success border border-severity-success-border',
        info: 'bg-severity-info-bg text-severity-info border border-severity-info-border',
        accent: 'bg-accent-light text-accent border border-indigo-200/50',
      },
      size: {
        sm: 'text-[11px] px-1.5 py-0.25',
        md: 'text-xs px-2 py-0.5',
        lg: 'text-xs px-2.5 py-1 rounded-lg',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'md',
    },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, size, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant, size }), className)} {...props} />;
}
