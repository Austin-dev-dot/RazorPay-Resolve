import * as React from 'react';
import { Check, Circle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SettlementStep } from '@/data/types';

interface ProgressStepsProps {
  steps: SettlementStep[];
  currentStepIndex?: number;
  className?: string;
  onStepClick?: (index: number) => void;
}

export function ProgressSteps({
  steps,
  currentStepIndex = 1,
  className,
  onStepClick,
}: ProgressStepsProps) {
  const completedCount = steps.filter((s) => s.completed).length;

  return (
    <div className={cn('space-y-4', className)}>
      <div className="flex items-center justify-between text-xs text-content-secondary mb-2">
        <span className="font-medium text-content-primary">Verification Progress</span>
        <span className="tabular-nums font-semibold text-content-primary">
          {completedCount} of {steps.length} completed
        </span>
      </div>

      <div className="space-y-3">
        {steps.map((step, index) => {
          const isCompleted = step.completed;
          const isCurrent = index === currentStepIndex && !isCompleted;

          return (
            <div
              key={step.id}
              onClick={() => onStepClick && onStepClick(index)}
              className={cn(
                'flex items-start gap-3.5 p-3.5 rounded-xl border transition-all',
                isCompleted
                  ? 'bg-surface-secondary border-border text-content-primary'
                  : isCurrent
                  ? 'bg-surface-secondary border-border-prominent shadow-sm'
                  : 'bg-surface-tertiary/60 border-border-subtle opacity-70',
                onStepClick && 'cursor-pointer hover:border-slate-300'
              )}
            >
              <div
                className={cn(
                  'h-6 w-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 text-xs font-semibold',
                  isCompleted
                    ? 'bg-content-primary text-white dark:bg-[#f5f5f7] dark:text-[#1d1d1f]'
                    : isCurrent
                    ? 'bg-content-primary text-white dark:bg-[#f5f5f7] dark:text-[#1d1d1f] ring-4 ring-slate-900/10'
                    : 'bg-slate-200 text-slate-600'
                )}
              >
                {isCompleted ? <Check className="h-3.5 w-3.5" strokeWidth={2.5} /> : index + 1}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h5
                    className={cn(
                      'text-xs font-semibold',
                      isCompleted
                        ? 'text-content-primary'
                        : isCurrent
                        ? 'text-content-primary'
                        : 'text-content-secondary'
                    )}
                  >
                    {step.label}
                  </h5>
                  <span className="text-[11px] font-medium text-content-tertiary">
                    {isCompleted ? 'Completed' : isCurrent ? 'In progress' : 'Pending'}
                  </span>
                </div>
                <p className="text-xs text-content-secondary mt-0.5 leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
