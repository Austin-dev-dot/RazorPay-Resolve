'use client';

import * as React from 'react';
import Link from 'next/link';
import { ArrowRight, ChevronRight } from 'lucide-react';
import { Issue } from '@/data/types';
import { formatCurrency, formatCurrencyCompact } from '@/lib/utils';
import { StatusBadge } from './StatusBadge';
import { Card } from './Card';
import { Button } from './Button';

interface IssueCardProps {
  issue: Issue;
  variant?: 'compact' | 'detailed';
  onResolveClick?: (e: React.MouseEvent) => void;
}

export function IssueCard({ issue, variant = 'detailed', onResolveClick }: IssueCardProps) {
  const targetHref =
    issue.actionHref ||
    (issue.relatedPaymentIds && issue.relatedPaymentIds.length > 0
      ? `/payments/${issue.relatedPaymentIds[0]}`
      : `/issues/${issue.id}`);

  const severityDot = issue.severity === 'critical' ? 'bg-content-primary' : 'bg-content-secondary';

  if (variant === 'compact') {
    return (
      <Link href={targetHref} className="block group">
        <Card hoverable className="p-5 border-border transition-all group-hover:border-slate-300">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <span className={`mt-1.5 h-2.5 w-2.5 rounded-full shrink-0 ${severityDot}`} />
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="text-sm font-semibold text-content-primary transition-colors">
                    {issue.title}
                  </h4>
                  <StatusBadge severity={issue.severity} size="sm" showDot={false} />
                </div>
                <p className="text-xs text-content-secondary mt-1 line-clamp-1">
                  {issue.description}
                </p>
              </div>
            </div>

            <div className="text-right shrink-0">
              {issue.affectedAmount > 0 && (
                <div className="text-sm font-semibold text-content-primary tabular-nums">
                  {formatCurrencyCompact(issue.affectedAmount)}
                </div>
              )}
              {issue.affectedCount > 1 && (
                <div className="text-[11px] text-content-tertiary">
                  {issue.affectedCount} affected
                </div>
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-border-subtle grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div>
              <span className="text-content-tertiary font-medium block text-[10px] uppercase tracking-wider">
                What Happened
              </span>
              <p className="text-content-secondary mt-0.5 line-clamp-1">{issue.description}</p>
            </div>
            <div>
              <span className="text-content-tertiary font-medium block text-[10px] uppercase tracking-wider">
                Why
              </span>
              <p className="text-content-secondary mt-0.5 line-clamp-1">{issue.explanation}</p>
            </div>
            <div>
              <span className="text-content-tertiary font-medium block text-[10px] uppercase tracking-wider">
                What You Can Do
              </span>
              <p className="text-content-primary font-medium mt-0.5 line-clamp-1 flex items-center justify-between">
                <span>{issue.whatToDo}</span>
                <ChevronRight className="h-3.5 w-3.5 text-content-tertiary group-hover:translate-x-0.5 transition-transform" />
              </p>
            </div>
          </div>
        </Card>
      </Link>
    );
  }

  return (
    <Card className="p-6 border-border hover:shadow-card-hover transition-all">
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className={`mt-1 h-3 w-3 rounded-full shrink-0 ${severityDot}`} />
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h4 className="text-base font-semibold text-content-primary">{issue.title}</h4>
              <StatusBadge severity={issue.severity} size="sm" showDot={false} />
              <StatusBadge issueStatus={issue.status} size="sm" showDot={true} />
            </div>
            <p className="text-sm text-content-secondary mt-1">{issue.description}</p>
          </div>
        </div>

        <div className="flex items-baseline md:flex-col md:items-end justify-between shrink-0 pl-6 md:pl-0 border-t md:border-t-0 pt-2 md:pt-0 border-border-subtle">
          {issue.affectedAmount > 0 && (
            <div className="text-lg font-semibold text-content-primary tabular-nums">
              {formatCurrency(issue.affectedAmount)}
            </div>
          )}
          {issue.affectedCount > 1 && (
            <div className="text-xs text-content-secondary">
              {issue.affectedCount} payments affected
            </div>
          )}
        </div>
      </div>

      {/* Explicit 3-part Apple explanation section */}
      <div className="mt-5 pt-4 border-t border-border-subtle grid grid-cols-1 md:grid-cols-3 gap-5 text-xs bg-surface-primary/60 rounded-xl p-4">
        <div>
          <span className="text-[10px] font-semibold uppercase tracking-wider text-content-tertiary">
            What happened
          </span>
          <p className="text-content-secondary mt-1 leading-relaxed">{issue.description}</p>
        </div>

        <div>
          <span className="text-[10px] font-semibold uppercase tracking-wider text-content-tertiary">
            Why
          </span>
          <p className="text-content-secondary mt-1 leading-relaxed">{issue.explanation}</p>
        </div>

        <div>
          <span className="text-[10px] font-semibold uppercase tracking-wider text-content-tertiary">
            What you can do
          </span>
          <p className="text-content-primary font-medium mt-1 leading-relaxed">{issue.whatToDo}</p>
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between pt-2">
        <div className="text-xs text-content-tertiary">
          {issue.createdAt ? 'Detected recently · Automated monitoring active' : 'Automated monitoring active'}
        </div>

        <div className="flex items-center gap-2">
          {issue.recommendedAction && (
            <span className="text-xs text-content-secondary hidden lg:inline-block font-medium">
              Recommended: {issue.recommendedAction}
            </span>
          )}
          <Link href={targetHref}>
            <Button
              variant={issue.severity === 'critical' ? 'primary' : 'secondary'}
              size="sm"
              className="gap-1.5"
            >
              <span>{issue.actionLabel || 'Inspect'}</span>
              <ArrowRight className="h-3.5 w-3.5" strokeWidth={1.75} />
            </Button>
          </Link>
        </div>
      </div>
    </Card>
  );
}
