'use client';

import * as React from 'react';
import { ShieldCheck, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HealthScoreProps {
  score: number;
  maxScore?: number;
  label?: string;
  statusText?: string;
  size?: 'sm' | 'md' | 'lg';
  showRadialMeter?: boolean;
  className?: string;
}

export function HealthScore({
  score,
  maxScore = 100,
  label = 'Account Health',
  statusText = 'Healthy',
  size = 'lg',
  showRadialMeter = true,
  className,
}: HealthScoreProps) {
  const normalizedScore = Math.min(Math.max(score, 0), maxScore);
  const percentage = (normalizedScore / maxScore) * 100;

  const scoreColor = 'text-content-primary stroke-content-primary';
  const badgeColor = 'bg-surface-tertiary text-content-secondary border-border-subtle';

  // SVG parameters
  const radius = 54;
  const strokeWidth = 8;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className={cn('flex items-center gap-6', className)}>
      {showRadialMeter && (
        <div className="relative flex items-center justify-center shrink-0">
          <svg
            className="w-32 h-32 -rotate-90 transform"
            viewBox="0 0 128 128"
            aria-hidden="true"
          >
            {/* Background track */}
            <circle
              cx="64"
              cy="64"
              r={radius}
              className="stroke-slate-200"
              strokeWidth={strokeWidth}
              fill="transparent"
            />
            {/* Animated progress arc */}
            <circle
              cx="64"
              cy="64"
              r={radius}
              className={cn('transition-all duration-1000 ease-out', scoreColor)}
              strokeWidth={strokeWidth}
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
            />
          </svg>

          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="text-3xl font-bold tracking-tight text-content-primary tabular-nums">
              {score}
            </span>
            <span className="text-[11px] font-medium text-content-tertiary">/ {maxScore}</span>
          </div>
        </div>
      )}

      <div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-content-tertiary">
            {label}
          </span>
          <span
            className={cn(
              'inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full border',
              badgeColor
            )}
          >
            <CheckCircle2 className="h-3 w-3" strokeWidth={2} />
            <span>{statusText}</span>
          </span>
        </div>

        <p className="text-xs text-content-secondary mt-1.5 leading-relaxed max-w-sm">
          Calculated across payment reliability, verification status, chargeback probability, and
          regulatory nodal compliance.
        </p>
      </div>
    </div>
  );
}
