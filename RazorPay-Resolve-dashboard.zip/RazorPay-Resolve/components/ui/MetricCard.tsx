import * as React from 'react';
import { ArrowUpRight, ArrowDownRight, CheckCircle2, ShieldCheck, LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card } from './Card';

interface MetricCardProps {
  label: string;
  value: string;
  delta?: string;
  deltaType?: 'positive' | 'negative' | 'neutral';
  statusText?: string;
  statusType?: 'healthy' | 'warning' | 'critical';
  icon?: LucideIcon;
  subtitle?: string;
  className?: string;
  onClick?: () => void;
}

export function MetricCard({
  label,
  value,
  delta,
  deltaType = 'positive',
  statusText,
  statusType = 'healthy',
  icon: Icon,
  subtitle,
  className,
  onClick,
}: MetricCardProps) {
  return (
    <Card
      hoverable={!!onClick}
      onClick={onClick}
      className={cn('p-6 flex flex-col justify-between relative overflow-hidden group', className)}
    >
      <div>
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium uppercase tracking-wider text-content-tertiary">
            {label}
          </span>
          {Icon && (
            <div className="h-7 w-7 rounded-lg bg-surface-tertiary flex items-center justify-center text-content-secondary group-hover:text-content-primary transition-colors">
              <Icon className="h-4 w-4" strokeWidth={1.75} />
            </div>
          )}
        </div>

        <div className="mt-3 flex items-baseline gap-3">
          <span className="text-3xl font-semibold tracking-tight text-content-primary tabular-nums">
            {value}
          </span>

          {delta && (
            <span
              className={cn(
                'inline-flex items-center text-xs font-medium gap-0.5 px-2 py-0.5 rounded-full border',
                'text-content-secondary bg-surface-tertiary border-border-subtle'
              )}
            >
              {deltaType === 'positive' && <ArrowUpRight className="h-3 w-3" strokeWidth={2} />}
              {deltaType === 'negative' && <ArrowDownRight className="h-3 w-3" strokeWidth={2} />}
              <span>{delta}</span>
            </span>
          )}

          {statusText && (
            <span
              className={cn(
                'inline-flex items-center text-xs font-medium gap-1 px-2.5 py-0.5 rounded-full border',
                'text-content-secondary bg-surface-tertiary border-border-subtle'
              )}
            >
              {statusType === 'healthy' && <CheckCircle2 className="h-3 w-3 text-content-primary" strokeWidth={2} />}
              <span>{statusText}</span>
            </span>
          )}
        </div>
      </div>

      {subtitle && (
        <div className="mt-4 pt-3 border-t border-border-subtle flex items-center justify-between text-xs text-content-secondary">
          <span>{subtitle}</span>
        </div>
      )}
    </Card>
  );
}
