'use client';

import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const buttonVariants = cva(
  'inline-flex items-center justify-center whitespace-nowrap rounded-lg text-sm font-semibold transition-all duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rzp-blue/25 active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40 select-none cursor-pointer',
  {
    variants: {
      variant: {
        primary:
          'bg-rzp-blue text-white shadow-sm hover:bg-rzp-blue-hover active:bg-rzp-blue-dark border border-transparent dark:bg-[#f5f5f7] dark:text-[#1d1d1f] dark:hover:bg-[#d1d1d6] dark:active:bg-[#aeaeb2]',
        accent:
          'bg-rzp-blue text-white shadow-sm hover:bg-rzp-blue-hover active:bg-rzp-blue-dark border border-transparent dark:bg-[#f5f5f7] dark:text-[#1d1d1f] dark:hover:bg-[#d1d1d6] dark:active:bg-[#aeaeb2]',
        secondary:
          'bg-surface-tertiary text-content-primary hover:bg-slate-200/70 active:bg-slate-200 border border-border-subtle',
        glass:
          'bg-white/80 backdrop-blur-md border border-border text-content-primary shadow-sm hover:bg-white hover:shadow-card active:bg-white',
        ghost:
          'text-content-secondary hover:bg-slate-100 hover:text-content-primary active:bg-slate-200/60',
        destructive:
          'bg-surface-tertiary text-content-primary border border-border hover:bg-slate-200 active:bg-slate-300',
        outline:
          'border border-border bg-transparent text-content-primary hover:bg-slate-100 active:bg-slate-200/50',
      },
      size: {
        sm: 'h-8 px-3 text-xs rounded-lg gap-1.5',
        md: 'h-9 px-4 text-sm gap-2',
        lg: 'h-11 px-5 text-base rounded-xl gap-2.5',
        icon: 'h-9 w-9 p-0',
        'icon-sm': 'h-8 w-8 p-0 rounded-lg',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(buttonVariants({ variant, size, className }))}
        {...props}
      />
    );
  }
);

Button.displayName = 'Button';
