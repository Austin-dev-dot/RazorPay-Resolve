'use client';

import * as React from 'react';
import Link from 'next/link';
import { Sparkles, User, ArrowRight } from 'lucide-react';
import { AssistantMessage as IAssistantMessage } from '@/data/types';
import { Button } from '@/components/ui/Button';

interface AssistantMessageProps {
  message: IAssistantMessage;
  onActionClick?: (action: string) => void;
}

export function AssistantMessage({ message, onActionClick }: AssistantMessageProps) {
  const isAssistant = message.role === 'assistant';

  return (
    <div
      className={`flex items-start gap-3 text-xs leading-relaxed ${
        isAssistant ? 'justify-start' : 'justify-end'
      }`}
    >
      {isAssistant && (
        <div className="h-7 w-7 rounded-xl bg-content-primary text-white dark:bg-[#f5f5f7] dark:text-[#1d1d1f] flex items-center justify-center shrink-0 shadow-sm mt-0.5">
          <Sparkles className="h-3.5 w-3.5" />
        </div>
      )}

      <div
        className={`max-w-[85%] rounded-2xl p-4 shadow-sm ${
          isAssistant
            ? 'bg-white border border-border text-content-primary'
            : 'bg-content-primary text-white dark:bg-[#f5f5f7] dark:text-[#1d1d1f]'
        }`}
      >
        <p className="whitespace-pre-line leading-relaxed">{message.content}</p>

        {/* Interactive action buttons */}
        {isAssistant && message.actions && message.actions.length > 0 && (
          <div className="mt-3.5 pt-3 border-t border-border-subtle flex flex-wrap gap-2">
            {message.actions.map((act, idx) => {
              if (act.href) {
                return (
                  <Link key={idx} href={act.href}>
                    <Button variant="secondary" size="sm" className="h-7 text-xs gap-1">
                      <span>{act.label}</span>
                      <ArrowRight className="h-3 w-3" />
                    </Button>
                  </Link>
                );
              }
              return (
                <Button
                  key={idx}
                  variant="secondary"
                  size="sm"
                  onClick={() => onActionClick && onActionClick(act.action || act.label)}
                  className="h-7 text-xs"
                >
                  {act.label}
                </Button>
              );
            })}
          </div>
        )}
      </div>

      {!isAssistant && (
        <div className="h-7 w-7 rounded-xl bg-slate-200 text-slate-700 flex items-center justify-center shrink-0 mt-0.5">
          <User className="h-3.5 w-3.5" />
        </div>
      )}
    </div>
  );
}
