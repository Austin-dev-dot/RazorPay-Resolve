'use client';

import * as React from 'react';
import {
  Sparkles,
  X,
  Send,
  HelpCircle,
  ShieldCheck,
  RefreshCw,
  CornerDownLeft,
} from 'lucide-react';
import { AssistantMessage as IAssistantMessage } from '@/data/types';
import { initialAssistantMessages, getAssistantResponse } from '@/data/assistant';
import { AssistantMessage } from './AssistantMessage';
import { Button } from '@/components/ui/Button';

interface AssistantPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AssistantPanel({ isOpen, onClose }: AssistantPanelProps) {
  const [messages, setMessages] = React.useState<IAssistantMessage[]>(initialAssistantMessages);
  const [inputQuery, setInputQuery] = React.useState('');
  const [isTyping, setIsTyping] = React.useState(false);
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, messages, isTyping]);

  if (!isOpen) return null;

  const handleSend = (textToSend?: string) => {
    const q = textToSend || inputQuery;
    if (!q.trim()) return;

    const userMsg: IAssistantMessage = {
      id: `user_${Date.now()}`,
      role: 'user',
      content: q,
      timestamp: 'Just now',
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsTyping(true);

    setTimeout(() => {
      const resp = getAssistantResponse(q);
      setIsTyping(false);
      setMessages((prev) => [...prev, resp]);
    }, 800);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/30 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Drawer Panel */}
      <div className="relative z-50 w-full max-w-md bg-white h-full shadow-2xl border-l border-border flex flex-col justify-between animate-slide-in-right">
        {/* Header */}
        <div className="p-4 px-6 border-b border-border flex items-center justify-between bg-surface-secondary">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-xl bg-content-primary text-white dark:bg-[#f5f5f7] dark:text-[#1d1d1f] flex items-center justify-center shadow-sm">
              <Sparkles className="h-4 w-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-semibold text-content-primary">Ask Resolve</h3>
                <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded-md bg-surface-tertiary text-content-secondary border border-border-subtle">
                  Data-Grounded
                </span>
              </div>
              <p className="text-[11px] text-content-secondary">
                Clear answers, grounded in gateway data
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-content-tertiary hover:text-content-primary rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Chat History Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-surface-primary/40 scrollbar-none">
          {messages.map((msg) => (
            <AssistantMessage
              key={msg.id}
              message={msg}
              onActionClick={(actionText) => handleSend(actionText)}
            />
          ))}

          {isTyping && (
            <div className="flex items-center gap-2 text-xs text-content-tertiary bg-white p-3 rounded-xl border border-border-subtle max-w-[120px]">
              <RefreshCw className="h-3 w-3 animate-spin text-content-primary" />
              <span>Analyzing...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 border-t border-border bg-white space-y-3">
          {/* Quick preset chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
            <button
              onClick={() => handleSend('Why did this payment fail?')}
              className="px-2.5 py-1 rounded-full bg-surface-tertiary text-content-secondary hover:text-content-primary hover:bg-slate-200/80 whitespace-nowrap transition-colors cursor-pointer"
            >
              Why did ₹7,499 fail?
            </button>
            <button
              onClick={() => handleSend('Customer paid but dashboard says failed')}
              className="px-2.5 py-1 rounded-full bg-surface-tertiary text-content-secondary hover:text-content-primary hover:bg-slate-200/80 whitespace-nowrap transition-colors cursor-pointer"
            >
              Unresolved ₹4,999
            </button>
            <button
              onClick={() => handleSend('Settlement delayed')}
              className="px-2.5 py-1 rounded-full bg-surface-tertiary text-content-secondary hover:text-content-primary hover:bg-slate-200/80 whitespace-nowrap transition-colors cursor-pointer"
            >
              Settlement hold
            </button>
          </div>

          <div className="relative flex items-center">
            <input
              type="text"
              placeholder="Ask about payment failure, settlement hold, or ID..."
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full text-xs pr-10 pl-3.5 py-3 rounded-xl bg-surface-tertiary border border-border-subtle focus:border-border-prominent outline-none text-content-primary placeholder:text-content-tertiary transition-colors"
            />
            <button
              onClick={() => handleSend()}
              disabled={!inputQuery.trim()}
              className="absolute right-2.5 p-1.5 rounded-lg bg-content-primary text-white dark:bg-[#f5f5f7] dark:text-[#1d1d1f] disabled:opacity-30 hover:bg-slate-800 dark:hover:bg-[#d1d1d6] transition-all cursor-pointer"
            >
              <Send className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="flex items-center justify-between text-[10px] text-content-tertiary px-1">
            <span>Explains Razorpay gateway telemetry. Zero hallucinations.</span>
            <span className="font-mono">Press ↵</span>
          </div>
        </div>
      </div>
    </div>
  );
}
