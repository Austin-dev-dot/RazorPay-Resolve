'use client';

import * as React from 'react';
import Link from 'next/link';
import {
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  Globe,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  Zap,
} from 'lucide-react';
import { Issue } from '@/data/types';
import { formatCurrency, formatCurrencyCompact } from '@/lib/utils';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

interface FailureIntelligenceProps {
  issue: Issue;
  onEnableAlternativeMethods?: () => void;
}

export function FailureIntelligence({
  issue,
  onEnableAlternativeMethods,
}: FailureIntelligenceProps) {
  const pattern = issue.patternData;
  const causes = pattern?.causes || [];

  return (
    <div className="space-y-6">
      {/* Hero pattern alert banner */}
      <Card className="p-6 md:p-8 border-amber-200/80 bg-gradient-to-br from-amber-50/40 via-white to-orange-50/30">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse" />
              <span className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                Pattern Anomaly Detected
              </span>
              <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200">
                Automatic Intelligence
              </span>
            </div>

            <h2 className="text-2xl font-bold tracking-tight text-content-primary mt-2">
              You're losing more international payments than usual
            </h2>
            <p className="text-sm text-content-secondary mt-1 max-w-2xl leading-relaxed">
              {issue.description}. Our predictive system identified that standard card authentication
              (3DS step-up) is dropping at foreign issuing banks before reaching Razorpay.
            </p>
          </div>

          <div className="flex items-center gap-4 shrink-0 bg-white p-4 rounded-xl border border-border-subtle shadow-sm">
            <div>
              <div className="text-xs text-content-tertiary">Revenue at risk</div>
              <div className="text-2xl font-bold text-content-primary tabular-nums">
                {formatCurrencyCompact(issue.affectedAmount)}
              </div>
            </div>
            <div className="h-8 w-px bg-border-subtle" />
            <div>
              <div className="text-xs text-content-tertiary">Failure spike</div>
              <div className="text-xl font-bold text-rose-600 flex items-center gap-0.5 tabular-nums">
                <TrendingUp className="h-4 w-4" />
                <span>↑ {pattern?.trend || 27}%</span>
              </div>
              <div className="text-[10px] text-content-tertiary">vs previous 7 days</div>
            </div>
          </div>
        </div>

        {/* Breakdown bar graph */}
        <div className="mt-8 pt-6 border-t border-amber-200/60">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-content-tertiary">
              What's causing it?
            </h4>
            <span className="text-xs text-content-secondary">
              Based on {issue.affectedCount} failed attempts
            </span>
          </div>

          {/* Visual stacked percentage bar */}
          <div className="h-3 w-full rounded-full bg-slate-100 overflow-hidden flex gap-0.5 p-0.5">
            {causes.map((cause, idx) => {
              const bgColors = [
                'bg-rose-500',
                'bg-amber-500',
                'bg-indigo-400',
                'bg-slate-300',
              ];
              return (
                <div
                  key={idx}
                  style={{ width: `${cause.percentage}%` }}
                  className={`h-full rounded-full ${bgColors[idx % bgColors.length]} transition-all`}
                  title={`${cause.label}: ${cause.percentage}%`}
                />
              );
            })}
          </div>

          {/* Breakdown percentage legend items */}
          <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
            {causes.map((cause, idx) => {
              const dotColors = [
                'bg-rose-500',
                'bg-amber-500',
                'bg-indigo-400',
                'bg-slate-300',
              ];
              return (
                <div key={idx} className="bg-white/80 p-3 rounded-lg border border-border-subtle">
                  <div className="flex items-center gap-1.5">
                    <span className={`h-2 w-2 rounded-full ${dotColors[idx % dotColors.length]}`} />
                    <span className="text-lg font-bold text-content-primary tabular-nums">
                      {cause.percentage}%
                    </span>
                  </div>
                  <span className="text-xs text-content-secondary block mt-0.5 leading-snug line-clamp-2">
                    {cause.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recommended Action Box */}
        <div className="mt-8 p-5 bg-white rounded-xl border border-indigo-100 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="h-9 w-9 rounded-xl bg-accent-light text-accent flex items-center justify-center shrink-0 mt-0.5">
              <Zap className="h-5 w-5" strokeWidth={2} />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-accent block">
                Recommended Action
              </span>
              <p className="text-sm font-semibold text-content-primary mt-0.5">
                {issue.recommendedAction ||
                  'Enable additional payment methods for international customers'}
              </p>
              <p className="text-xs text-content-secondary mt-1 leading-relaxed">
                Activating PayPal and multi-currency checkout routes payments around card 3DS
                mandates, recovering approximately 70% of dropped transactions.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0 pl-12 sm:pl-0">
            <Link href="/payments?filter=failed_intl">
              <Button variant="secondary" size="sm">
                View affected payments
              </Button>
            </Link>
            <Button
              variant="accent"
              size="sm"
              onClick={
                onEnableAlternativeMethods ||
                (() => alert('Alternative rails (PayPal, Swift) configured successfully!'))
              }
              className="gap-1.5"
            >
              <span>Enable 1-Click</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
