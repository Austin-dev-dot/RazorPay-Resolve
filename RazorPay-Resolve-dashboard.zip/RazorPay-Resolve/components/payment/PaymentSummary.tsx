import * as React from 'react';
import {
  Smartphone,
  CreditCard,
  Building2,
  Wallet,
  Clock,
  Mail,
  Phone,
  Copy,
  Check,
  ShieldCheck,
  ExternalLink,
} from 'lucide-react';
import { Payment } from '@/data/types';
import { formatCurrency, formatDate } from '@/lib/utils';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Card } from '@/components/ui/Card';

interface PaymentSummaryProps {
  payment: Payment;
}

export function PaymentSummary({ payment }: PaymentSummaryProps) {
  const [copied, setCopied] = React.useState(false);

  const handleCopyId = () => {
    if (typeof navigator !== 'undefined') {
      navigator.clipboard.writeText(payment.id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getMethodIcon = () => {
    switch (payment.method) {
      case 'upi':
        return <Smartphone className="h-4 w-4 text-emerald-600" strokeWidth={1.75} />;
      case 'card':
        return <CreditCard className="h-4 w-4 text-indigo-600" strokeWidth={1.75} />;
      case 'netbanking':
        return <Building2 className="h-4 w-4 text-blue-600" strokeWidth={1.75} />;
      case 'wallet':
        return <Wallet className="h-4 w-4 text-purple-600" strokeWidth={1.75} />;
    }
  };

  const formattedDate =
    typeof payment.createdAt === 'string'
      ? payment.createdAt
      : formatDate(payment.createdAt);

  return (
    <Card className="p-6 md:p-8 border-border">
      {/* Top status bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-6 border-b border-border-subtle">
        <div className="flex items-center gap-3">
          <StatusBadge status={payment.status} size="lg" />
          <span className="text-xs text-content-secondary hidden sm:inline-block">
            Order ID: <span className="font-mono text-content-primary">{payment.orderId}</span>
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyId}
            className="inline-flex items-center gap-1.5 text-xs text-content-secondary hover:text-content-primary bg-surface-tertiary px-3 py-1.5 rounded-lg border border-border-subtle transition-colors cursor-pointer"
            title="Copy Payment ID"
          >
            {copied ? (
              <Check className="h-3.5 w-3.5 text-emerald-600" strokeWidth={2} />
            ) : (
              <Copy className="h-3.5 w-3.5" strokeWidth={1.75} />
            )}
            <span className="font-mono">{payment.id}</span>
          </button>
        </div>
      </div>

      {/* Hero amount and primary details */}
      <div className="mt-6 flex flex-col md:flex-row md:items-baseline justify-between gap-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-content-tertiary">
            Payment Amount
          </span>
          <div className="mt-1 flex items-baseline gap-3">
            <h1 className="text-4xl font-bold tracking-tight text-content-primary tabular-nums">
              {formatCurrency(payment.amount)}
            </h1>
            <span className="text-sm font-medium text-content-secondary">INR</span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 md:gap-8 text-xs">
          <div>
            <span className="text-content-tertiary uppercase tracking-wider block text-[10px] font-semibold">
              Customer
            </span>
            <div className="mt-1 font-medium text-content-primary truncate max-w-[160px]">
              {payment.customer.name}
            </div>
            <div className="text-content-secondary text-[11px] truncate max-w-[160px]">
              {payment.customer.email}
            </div>
          </div>

          <div>
            <span className="text-content-tertiary uppercase tracking-wider block text-[10px] font-semibold">
              Method
            </span>
            <div className="mt-1 flex items-center gap-1.5 font-medium text-content-primary uppercase">
              {getMethodIcon()}
              <span>{payment.method}</span>
            </div>
            <div className="text-content-secondary text-[11px] font-mono">
              {payment.upi?.vpa ||
                (payment.card && `${payment.card.issuer} •••• ${payment.card.last4}`) ||
                payment.bankName ||
                'Direct'}
            </div>
          </div>

          <div>
            <span className="text-content-tertiary uppercase tracking-wider block text-[10px] font-semibold">
              Timestamp
            </span>
            <div className="mt-1 font-medium text-content-primary">{formattedDate}</div>
            <div className="text-content-secondary text-[11px]">
              {payment.bankStatus ? `Bank: ${payment.bankStatus}` : 'Rail active'}
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
