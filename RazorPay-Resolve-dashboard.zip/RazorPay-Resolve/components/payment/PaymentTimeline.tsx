'use client';

import * as React from 'react';
import {
  CheckCircle2,
  Clock,
  AlertCircle,
  ArrowDown,
  ShieldAlert,
  Smartphone,
  Building2,
  Cpu,
  RefreshCw,
} from 'lucide-react';
import { TimelineEvent, TimelineEventStatus } from '@/data/types';
import { cn } from '@/lib/utils';

interface PaymentTimelineProps {
  events: TimelineEvent[];
  className?: string;
}

export function PaymentTimeline({ events, className }: PaymentTimelineProps) {
  const [expandedId, setExpandedId] = React.useState<string | null>(null);

  const getStatusIcon = (status: TimelineEventStatus, title: string) => {
    if (status === 'completed') {
      return <CheckCircle2 className="h-4 w-4 text-emerald-600" strokeWidth={2} />;
    }
    if (status === 'current') {
      return <Clock className="h-4 w-4 text-amber-600 animate-pulse" strokeWidth={2} />;
    }
    if (status === 'failed') {
      return <AlertCircle className="h-4 w-4 text-rose-600" strokeWidth={2} />;
    }
    return <div className="h-2 w-2 rounded-full bg-slate-300" />;
  };

  const getNodeStyles = (status: TimelineEventStatus) => {
    if (status === 'completed') {
      return 'bg-emerald-50 border-emerald-200 text-emerald-700 shadow-sm';
    }
    if (status === 'current') {
      return 'bg-amber-50 border-amber-300 text-amber-800 shadow-sm ring-4 ring-amber-100/60';
    }
    if (status === 'failed') {
      return 'bg-rose-50 border-rose-200 text-rose-700 shadow-sm';
    }
    return 'bg-slate-100 border-slate-200 text-slate-400';
  };

  return (
    <div className={cn('relative', className)}>
      <div className="flex items-center justify-between pb-4 mb-2 border-b border-border-subtle">
        <div>
          <h4 className="text-sm font-semibold text-content-primary">Visual Transaction Lifecycle</h4>
          <p className="text-xs text-content-secondary mt-0.5">
            Real-time trace across Customer App, Issuer Bank CBS, and Razorpay Engine
          </p>
        </div>
        <span className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
          5 Lifecycle Steps
        </span>
      </div>

      <div className="relative pl-6 space-y-6 pt-2">
        {/* Continuous vertical timeline connector line */}
        <div
          className="absolute left-[2.05rem] top-5 bottom-8 w-[2px] bg-slate-200"
          aria-hidden="true"
        />

        {events.map((event, index) => {
          const isLast = index === events.length - 1;
          const isExpanded = expandedId === event.id;

          const formattedTime =
            typeof event.timestamp === 'string'
              ? event.timestamp
              : event.timestamp.toLocaleTimeString('en-IN', {
                  hour: 'numeric',
                  minute: '2-digit',
                  hour12: true,
                });

          return (
            <div key={event.id} className="relative group">
              <div className="flex items-start gap-4">
                {/* Timeline node icon */}
                <div
                  className={cn(
                    'relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-all duration-200',
                    getNodeStyles(event.status)
                  )}
                >
                  {getStatusIcon(event.status, event.title)}
                </div>

                {/* Event details card */}
                <div
                  onClick={() => setExpandedId(isExpanded ? null : event.id)}
                  className={cn(
                    'flex-1 rounded-xl border p-4 transition-all duration-150 cursor-pointer',
                    event.status === 'current'
                      ? 'bg-amber-50/40 border-amber-200/80 shadow-sm'
                      : event.status === 'completed'
                      ? 'bg-surface-secondary border-border hover:border-slate-300'
                      : 'bg-surface-tertiary/40 border-border-subtle'
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-content-primary">
                          {event.title}
                        </span>
                        {event.status === 'current' && (
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-200 animate-pulse">
                            Current state
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-content-secondary mt-1 leading-relaxed">
                        {event.description}
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-[11px] font-medium text-content-tertiary tabular-nums">
                        {formattedTime}
                      </span>
                    </div>
                  </div>

                  {event.detail && (
                    <div className="mt-3 pt-2.5 border-t border-border-subtle/80 flex items-center justify-between text-[11px] text-content-tertiary">
                      <span className="font-mono text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-700">
                        {event.detail}
                      </span>
                      <span className="text-accent text-[11px] font-medium">
                        {isExpanded ? 'Less detail' : 'Trace logs'}
                      </span>
                    </div>
                  )}

                  {isExpanded && (
                    <div className="mt-3 p-3 bg-slate-900 text-slate-200 rounded-lg text-xs font-mono overflow-x-auto space-y-1">
                      <div className="text-emerald-400 text-[10px]">
                        // Network Diagnostic Telemetry
                      </div>
                      <div>event_id: {event.id}</div>
                      <div>timestamp: {new Date().toISOString()}</div>
                      <div>status: {event.status}</div>
                      <div>rail: UPI 2.0 / NPCI switch</div>
                      <div>acquirer_response_code: 00_SUCCESS_PENDING_ACK</div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
