'use client';

import * as React from 'react';
import Link from 'next/link';
import {
  Smartphone,
  CreditCard,
  Building2,
  Wallet,
  ChevronRight,
  Search,
  Filter,
  ArrowUpDown,
} from 'lucide-react';
import { Payment, PaymentStatus } from '@/data/types';
import { formatCurrency, formatRelativeTime } from '@/lib/utils';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { EmptyState } from '@/components/ui/EmptyState';

interface PaymentTableProps {
  payments: Payment[];
  showFilters?: boolean;
  limit?: number;
  title?: string;
}

export function PaymentTable({
  payments,
  showFilters = false,
  limit,
  title,
}: PaymentTableProps) {
  const [searchQuery, setSearchQuery] = React.useState('');
  const [selectedStatus, setSelectedStatus] = React.useState<string>('all');

  const getMethodIcon = (method: string) => {
    switch (method) {
      case 'upi':
        return <Smartphone className="h-3.5 w-3.5 text-emerald-600" strokeWidth={1.75} />;
      case 'card':
        return <CreditCard className="h-3.5 w-3.5 text-indigo-600" strokeWidth={1.75} />;
      case 'netbanking':
        return <Building2 className="h-3.5 w-3.5 text-blue-600" strokeWidth={1.75} />;
      default:
        return <Wallet className="h-3.5 w-3.5 text-purple-600" strokeWidth={1.75} />;
    }
  };

  const filteredPayments = payments.filter((p) => {
    const matchesSearch =
      p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.customer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.card?.issuer && p.card.issuer.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (p.bankName && p.bankName.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus =
      selectedStatus === 'all'
        ? true
        : selectedStatus === 'at_risk'
        ? p.status === 'pending' || p.status === 'under_review' || p.status === 'disputed'
        : p.status === selectedStatus;

    return matchesSearch && matchesStatus;
  });

  const displayedPayments = limit ? filteredPayments.slice(0, limit) : filteredPayments;

  const statuses: { label: string; value: string }[] = [
    { label: 'All', value: 'all' },
    { label: 'At Risk', value: 'at_risk' },
    { label: 'Successful', value: 'successful' },
    { label: 'Pending', value: 'pending' },
    { label: 'Failed', value: 'failed' },
    { label: 'Under Review', value: 'under_review' },
  ];

  return (
    <div className="rounded-2xl border border-border bg-white shadow-card overflow-hidden">
      {/* Table Header / Filters Bar */}
      {(title || showFilters) && (
        <div className="p-5 border-b border-border-subtle flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface-secondary">
          {title && (
            <div>
              <h3 className="text-base font-semibold text-content-primary">{title}</h3>
              <p className="text-xs text-content-secondary mt-0.5">
                Live stream from payment gateway switch
              </p>
            </div>
          )}

          {showFilters && (
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              {/* Search input */}
              <div className="relative">
                <Search className="h-3.5 w-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-content-tertiary" />
                <input
                  type="text"
                  placeholder="Filter by customer, ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs bg-surface-tertiary border border-border-subtle rounded-lg text-content-primary placeholder:text-content-tertiary outline-none focus:border-accent w-full sm:w-56 transition-colors"
                />
              </div>

              {/* Status filter tabs */}
              <div className="flex items-center gap-1 bg-surface-tertiary p-1 rounded-lg overflow-x-auto scrollbar-none">
                {statuses.map((tab) => (
                  <button
                    key={tab.value}
                    onClick={() => setSelectedStatus(tab.value)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap transition-all select-none cursor-pointer ${
                      selectedStatus === tab.value
                        ? 'bg-white text-content-primary shadow-sm'
                        : 'text-content-secondary hover:text-content-primary'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Table Content */}
      {displayedPayments.length === 0 ? (
        <div className="p-8">
          <EmptyState
            title="No matching payments"
            description="Try adjusting your filter or search query to find the payment."
          />
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-border-subtle bg-surface-primary/60 text-[11px] font-semibold text-content-tertiary uppercase tracking-wider">
                <th className="py-3 px-6">Payment ID</th>
                <th className="py-3 px-6">Customer</th>
                <th className="py-3 px-6">Method</th>
                <th className="py-3 px-6">Amount</th>
                <th className="py-3 px-6">Status</th>
                <th className="py-3 px-6">Time</th>
                <th className="py-3 px-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-subtle text-xs">
              {displayedPayments.map((payment) => {
                const relativeTime =
                  typeof payment.createdAt === 'string'
                    ? payment.createdAt
                    : formatRelativeTime(payment.createdAt);

                return (
                  <tr
                    key={payment.id}
                    className="hover:bg-slate-50/80 transition-colors group cursor-pointer"
                  >
                    <td className="py-4 px-6 font-mono text-content-primary font-medium">
                      <Link
                        href={`/payments/${payment.id}`}
                        className="hover:text-accent flex items-center gap-1.5"
                      >
                        <span>{payment.id}</span>
                        {payment.status === 'pending' && (
                          <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse" />
                        )}
                      </Link>
                    </td>

                    <td className="py-4 px-6">
                      <div className="font-medium text-content-primary">
                        {payment.customer.name}
                      </div>
                      <div className="text-content-secondary text-[11px] truncate max-w-[160px]">
                        {payment.customer.email}
                      </div>
                    </td>

                    <td className="py-4 px-6">
                      <div className="flex items-center gap-1.5 uppercase font-medium text-content-primary">
                        {getMethodIcon(payment.method)}
                        <span>{payment.method}</span>
                      </div>
                      <div className="text-content-tertiary text-[11px] font-mono">
                        {payment.upi?.vpa ||
                          (payment.card && `${payment.card.issuer} •• ${payment.card.last4}`) ||
                          payment.bankName ||
                          ''}
                      </div>
                    </td>

                    <td className="py-4 px-6">
                      <span className="font-semibold text-content-primary tabular-nums text-sm">
                        {formatCurrency(payment.amount)}
                      </span>
                    </td>

                    <td className="py-4 px-6">
                      <StatusBadge status={payment.status} size="sm" />
                    </td>

                    <td className="py-4 px-6 text-content-secondary tabular-nums whitespace-nowrap">
                      {relativeTime}
                    </td>

                    <td className="py-4 px-6 text-right">
                      <Link
                        href={`/payments/${payment.id}`}
                        className="inline-flex items-center gap-1 text-xs font-medium text-accent hover:text-accent-hover transition-colors"
                      >
                        <span>Inspect</span>
                        <ChevronRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
