'use client';

import * as React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  UploadCloud,
  FileCheck,
  ShieldCheck,
  ArrowRight,
  Info,
  Lock,
} from 'lucide-react';
import { KYCIssue } from '@/data/types';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

interface KYCResolutionProps {
  kycIssue: KYCIssue;
}

export function KYCResolution({ kycIssue }: KYCResolutionProps) {
  const [fileUploaded, setFileUploaded] = React.useState(false);
  const [isProcessing, setIsProcessing] = React.useState(false);

  const handleUploadSimulate = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setFileUploaded(true);
    }, 1200);
  };

  return (
    <Card className="p-6 md:p-8 border-border">
      {/* Alert Header */}
      <div className="flex items-start justify-between gap-4 pb-6 border-b border-border-subtle">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center shrink-0 mt-0.5">
            <AlertTriangle className="h-5 w-5" strokeWidth={1.75} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-amber-800">
                Compliance Verification
              </span>
              <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-amber-100 text-amber-900">
                Action needed
              </span>
            </div>
            <h3 className="text-xl font-bold tracking-tight text-content-primary mt-1">
              {kycIssue.title}
            </h3>
            <p className="text-sm text-content-secondary mt-1 max-w-xl leading-relaxed">
              {kycIssue.description}: <strong className="text-content-primary">{kycIssue.reason}</strong>.
            </p>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-1 text-xs text-content-secondary bg-surface-tertiary px-3 py-1.5 rounded-lg border border-border-subtle">
          <Lock className="h-3.5 w-3.5 text-emerald-600" />
          <span>5 other documents preserved</span>
        </div>
      </div>

      {/* Side-by-Side Name Mismatch Card */}
      <div className="mt-6 p-5 rounded-xl bg-surface-primary border border-border-subtle">
        <div className="text-xs font-bold uppercase tracking-wider text-content-tertiary mb-3">
          Detected Discrepancy Analysis
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-white rounded-xl border border-border-subtle">
            <span className="text-[10px] font-bold uppercase tracking-wider text-content-tertiary">
              Registered Business Name
            </span>
            <div className="mt-1 text-base font-semibold text-content-primary">
              {kycIssue.registeredValue}
            </div>
            <span className="text-[11px] text-emerald-700 mt-1 block font-medium">
              ✓ Matches MCA / RoC records
            </span>
          </div>

          <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800">
              Uploaded Document Name
            </span>
            <div className="mt-1 text-base font-semibold text-amber-950">
              {kycIssue.documentValue}
            </div>
            <span className="text-[11px] text-rose-600 mt-1 block font-medium">
              ✕ Missing "Pvt Ltd" entity suffix
            </span>
          </div>
        </div>
      </div>

      {/* How to Fix It with Upload Section */}
      <div className="mt-6 p-6 rounded-xl border border-indigo-100 bg-gradient-to-br from-indigo-50/20 to-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-accent block">
              How to Fix It
            </span>
            <h4 className="text-base font-semibold text-content-primary mt-1">
              Upload an updated Certificate of Incorporation or GST Certificate
            </h4>
            <p className="text-xs text-content-secondary mt-1">
              The document must explicitly show: <strong className="text-content-primary font-mono">{kycIssue.registeredValue}</strong>
            </p>
          </div>

          {!fileUploaded ? (
            <Button
              variant="accent"
              size="md"
              disabled={isProcessing}
              onClick={handleUploadSimulate}
              className="gap-2 shrink-0 cursor-pointer"
            >
              <UploadCloud className="h-4 w-4" />
              <span>{isProcessing ? 'Verifying document...' : 'Upload document'}</span>
            </Button>
          ) : (
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 bg-emerald-100/80 px-4 py-2 rounded-xl border border-emerald-300">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              <span>Verified! Legal name matches MCA record.</span>
            </div>
          )}
        </div>
      </div>

      {/* Preserved Information Reassurance (Do NOT make user start over) */}
      <div className="mt-6 pt-5 border-t border-border-subtle">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-content-tertiary">
            <ShieldCheck className="h-4 w-4 text-emerald-600" />
            <span>Preserved Information (No Need to Re-enter)</span>
          </div>
          <span className="text-xs text-emerald-700 font-medium">All 5 fields securely locked</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
          {kycIssue.preservedFields.map((field, idx) => (
            <div
              key={idx}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-surface-primary border border-border-subtle text-xs text-content-secondary"
            >
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
              <span className="truncate">{field}</span>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}
