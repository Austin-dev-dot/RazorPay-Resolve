'use client';

import * as React from 'react';
import Link from 'next/link';
import {
  CheckCircle2,
  AlertCircle,
  Clock,
  Send,
  ShieldCheck,
  FileText,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { Payment } from '@/data/types';
import { formatCurrency } from '@/lib/utils';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

interface DiagnosticResultProps {
  payment: Payment;
  diagnosis: string;
  nextCheckMinutes?: number;
  onEscalate?: () => void;
}

export function DiagnosticResult({
  payment,
  diagnosis,
  nextCheckMinutes = 2,
  onEscalate,
}: DiagnosticResultProps) {
  const [showContextPayload, setShowContextPayload] = React.useState(false);
  const [ticketCreated, setTicketCreated] = React.useState(false);

  const handleEscalate = () => {
    setTicketCreated(true);
    if (onEscalate) onEscalate();
  };

  return (
    <Card className="p-6 md:p-8 border-indigo-200/70 bg-gradient-to-br from-indigo-50/20 via-white to-slate-50/50 shadow-elevated">
      {/* Found Issue Alert Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-border-subtle">
        <div className="flex items-center gap-2.5">
          <div className="h-8 w-8 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-100 flex items-center justify-center">
            <CheckCircle2 className="h-5 w-5" strokeWidth={2} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
                Diagnostic Complete
              </span>
              <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                Found match
              </span>
            </div>
            <h3 className="text-base font-semibold text-content-primary mt-0.5">
              We identified the exact payment state
            </h3>
          </div>
        </div>

        <div className="text-xs text-content-secondary bg-surface-tertiary px-3 py-1.5 rounded-lg border border-border-subtle font-mono">
          {payment.id}
        </div>
      </div>

      {/* Comparison Grid: Customer vs Bank vs Razorpay vs Webhook */}
      <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-surface-primary border border-border-subtle">
          <span className="text-[10px] font-bold uppercase tracking-wider text-content-tertiary">
            Customer Charge
          </span>
          <div className="mt-1.5 text-lg font-bold text-content-primary tabular-nums">
            {formatCurrency(payment.amount)}
          </div>
          <span className="text-[11px] text-emerald-700 flex items-center gap-1 font-medium mt-0.5">
            <CheckCircle2 className="h-3 w-3" /> Debited from user
          </span>
        </div>

        <div className="p-4 rounded-xl bg-surface-primary border border-border-subtle">
          <span className="text-[10px] font-bold uppercase tracking-wider text-content-tertiary">
            Issuer Bank Status
          </span>
          <div className="mt-1.5 text-base font-bold text-emerald-700">
            {payment.bankStatus || 'Successful'}
          </div>
          <span className="text-[11px] text-content-secondary block mt-0.5 font-mono">
            {payment.bankName || 'HDFC Bank'}
          </span>
        </div>

        <div className="p-4 rounded-xl bg-surface-primary border border-border-subtle">
          <span className="text-[10px] font-bold uppercase tracking-wider text-content-tertiary">
            Razorpay Status
          </span>
          <div className="mt-1.5 text-base font-bold text-amber-700">
            Pending Confirmation
          </div>
          <span className="text-[11px] text-amber-800 block mt-0.5">
            Awaiting final sync ack
          </span>
        </div>

        <div className="p-4 rounded-xl bg-surface-primary border border-border-subtle">
          <span className="text-[10px] font-bold uppercase tracking-wider text-content-tertiary">
            Webhook Delivery
          </span>
          <div className="mt-1.5 text-base font-bold text-slate-700">
            {payment.webhookStatus || 'Delayed'}
          </div>
          <span className="text-[11px] text-content-secondary block mt-0.5">
            Will auto-fire upon sync
          </span>
        </div>
      </div>

      {/* Diagnosis Explanation Box */}
      <div className="mt-6 p-5 bg-white rounded-xl border border-border-subtle shadow-sm">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-content-tertiary">
          <Sparkles className="h-3.5 w-3.5 text-accent" />
          <span>Root Cause Diagnosis</span>
        </div>
        <p className="mt-2 text-sm text-content-primary leading-relaxed font-medium">
          {diagnosis}
        </p>

        <div className="mt-4 pt-3 border-t border-border-subtle flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-content-secondary">
          <div className="flex items-center gap-1.5">
            <RefreshCw className="h-3.5 w-3.5 text-accent animate-spin" />
            <span>
              We are automatically monitoring it. Next check in{' '}
              <strong className="text-content-primary">{nextCheckMinutes} minutes</strong>.
            </span>
          </div>
          <span className="text-emerald-700 font-medium">
            99.4% auto-resolve without intervention
          </span>
        </div>
      </div>

      {/* Actions */}
      <div className="mt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Link href={`/payments/${payment.id}`}>
            <Button variant="primary" size="md" className="gap-1.5">
              <span>View payment lifecycle</span>
              <ExternalLink className="h-3.5 w-3.5" />
            </Button>
          </Link>

          {!ticketCreated ? (
            <Button variant="outline" size="md" onClick={handleEscalate}>
              Still need human support?
            </Button>
          ) : (
            <div className="inline-flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-200">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              <span>Diagnostic context attached to Ticket #RES-94821</span>
            </div>
          )}
        </div>

        <button
          onClick={() => setShowContextPayload(!showContextPayload)}
          className="text-xs text-accent font-medium hover:underline flex items-center gap-1 self-start sm:self-auto cursor-pointer"
        >
          <span>{showContextPayload ? 'Hide' : 'Inspect'} auto-attached diagnostic telemetry</span>
          {showContextPayload ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
        </button>
      </div>

      {/* Attached Context Preview Box */}
      {showContextPayload && (
        <div className="mt-5 p-4 rounded-xl bg-slate-900 text-slate-200 text-xs font-mono space-y-2">
          <div className="text-emerald-400 font-semibold text-[11px] pb-1 border-b border-slate-800">
            // AUTO-ATTACHED TO SUPPORT DISPATCH (Zero Merchant Repetition)
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
            <div>• Payment ID: {payment.id}</div>
            <div>• Customer: {payment.customer.email}</div>
            <div>• Amount: ₹{payment.amount / 100}</div>
            <div>• Bank Rail: {payment.bankName || 'HDFC Bank'}</div>
            <div>• Bank Status: Successful (UTR_ACK_OK)</div>
            <div>• Razorpay State: Pending Final Reconciler</div>
            <div>• Webhook Retries: 2 (Delayed due to network timeout)</div>
            <div>• Troubleshooting: UDIR Auto-Query queued</div>
          </div>
        </div>
      )}
    </Card>
  );
}
