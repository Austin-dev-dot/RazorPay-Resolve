import * as React from 'react';
import {
  CheckCircle2,
  ShieldCheck,
  Clock,
  ArrowRight,
  AlertCircle,
  HelpCircle,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

interface ResolutionStepProps {
  whatHappened: string;
  whatWeAreDoing: string[];
  whatYouNeedToDo: string;
  actionRequired?: boolean;
  actionButtonLabel?: string;
  onActionClick?: () => void;
  nextAutoCheck?: string;
  reassuranceNote?: string;
  className?: string;
}

export function ResolutionStep({
  whatHappened,
  whatWeAreDoing,
  whatYouNeedToDo,
  actionRequired = false,
  actionButtonLabel,
  onActionClick,
  nextAutoCheck = 'Next automatic check in 2 minutes',
  reassuranceNote = 'Your funds and customer inventory reservation are protected.',
  className,
}: ResolutionStepProps) {
  const isNoAction =
    whatYouNeedToDo.toLowerCase().includes('nothing') ||
    whatYouNeedToDo.toLowerCase().includes('no action');

  return (
    <div className={className}>
      <Card className="p-6 md:p-8 border-border bg-gradient-to-b from-white to-slate-50/50">
        <div className="flex items-center justify-between pb-5 border-b border-border-subtle">
          <div className="flex items-center gap-2.5">
            <div className="h-7 w-7 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-accent">
              <Sparkles className="h-4 w-4" strokeWidth={2} />
            </div>
            <div>
              <h3 className="text-base font-semibold text-content-primary">
                Intelligent Resolution Analysis
              </h3>
              <p className="text-xs text-content-secondary">
                Razorpay Resolve diagnosis and automated action plan
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 text-xs text-content-secondary bg-surface-tertiary px-3 py-1.5 rounded-full border border-border-subtle">
            <RefreshCw className="h-3 w-3 text-accent animate-spin" />
            <span>{nextAutoCheck}</span>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Column 1: What Happened */}
          <div className="bg-white p-5 rounded-xl border border-border-subtle shadow-sm flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-content-tertiary block">
                1. What Happened
              </span>
              <p className="text-sm font-medium text-content-primary mt-2 leading-relaxed">
                {whatHappened}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-border-subtle text-[11px] text-content-tertiary flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
              <span>Diagnosed by Resolve Engine</span>
            </div>
          </div>

          {/* Column 2: What We're Doing */}
          <div className="bg-white p-5 rounded-xl border border-border-subtle shadow-sm flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-content-tertiary block">
                2. What We're Doing
              </span>
              <ul className="mt-2 space-y-2">
                {whatWeAreDoing.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-content-secondary">
                    <CheckCircle2
                      className="h-3.5 w-3.5 text-emerald-600 mt-0.5 shrink-0"
                      strokeWidth={2}
                    />
                    <span className="leading-snug">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-4 pt-3 border-t border-border-subtle text-[11px] text-content-tertiary flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
              <span>Automated background recovery</span>
            </div>
          </div>

          {/* Column 3: What You Need To Do */}
          <div
            className={`p-5 rounded-xl border shadow-sm flex flex-col justify-between ${
              isNoAction
                ? 'bg-emerald-50/40 border-emerald-200/80 text-emerald-950'
                : 'bg-amber-50/50 border-amber-200 text-amber-950'
            }`}
          >
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider opacity-70 block">
                3. What You Need To Do
              </span>
              <div className="mt-2">
                <span className="text-xl font-bold tracking-tight block">
                  {isNoAction ? 'Nothing' : 'Action Required'}
                </span>
                <p className="text-xs mt-1.5 leading-relaxed opacity-90">{whatYouNeedToDo}</p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-black/[0.06] flex items-center justify-between">
              {isNoAction ? (
                <span className="text-[11px] font-medium text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>No merchant action needed</span>
                </span>
              ) : (
                actionButtonLabel && (
                  <Button
                    size="sm"
                    variant="primary"
                    onClick={onActionClick}
                    className="w-full gap-1.5"
                  >
                    <span>{actionButtonLabel}</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </Button>
                )
              )}
            </div>
          </div>
        </div>

        {reassuranceNote && (
          <div className="mt-6 p-3.5 rounded-xl bg-surface-tertiary/80 border border-border-subtle flex items-center justify-between text-xs text-content-secondary">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0" />
              <span>{reassuranceNote}</span>
            </div>
            <span className="text-[11px] font-medium text-content-tertiary hidden md:inline">
              ISO 27001 & RBI Compliant Nodal Protection
            </span>
          </div>
        )}
      </Card>
    </div>
  );
}
