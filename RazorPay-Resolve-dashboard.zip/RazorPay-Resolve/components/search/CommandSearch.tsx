'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Command } from 'cmdk';
import {
  Search,
  CreditCard,
  AlertTriangle,
  Wallet,
  Activity,
  LifeBuoy,
  ArrowRight,
  Sparkles,
  Smartphone,
  ExternalLink,
} from 'lucide-react';
import { payments } from '@/data/payments';
import { issues } from '@/data/issues';
import { settlements } from '@/data/settlements';
import { formatCurrency, formatRelativeTime } from '@/lib/utils';
import { StatusBadge } from '@/components/ui/StatusBadge';

interface CommandSearchProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CommandSearch({ open, onOpenChange }: CommandSearchProps) {
  const router = useRouter();

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        onOpenChange(!open);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, onOpenChange]);

  const runSelect = (callback: () => void) => {
    onOpenChange(false);
    callback();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh] px-4">
      {/* Frosted backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/30 backdrop-blur-md transition-opacity animate-fade-in"
        onClick={() => onOpenChange(false)}
      />

      {/* Palette container */}
      <Command
        className="relative z-50 w-full max-w-2xl overflow-hidden rounded-2xl border border-border bg-white shadow-elevated animate-scale-in"
      >
        <div className="flex items-center border-b border-border px-4 py-3 bg-surface-secondary">
          <Search className="mr-3 h-4 w-4 text-content-tertiary" strokeWidth={1.75} />
          <Command.Input
            placeholder="Search payment ID (pay_...), customer name, amount (₹4,999), or issue..."
            className="w-full bg-transparent text-sm outline-none placeholder:text-content-tertiary text-content-primary font-sans"
            autoFocus
          />
          <kbd className="hidden sm:inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-500 border border-slate-200">
            ESC
          </kbd>
        </div>

        <Command.List className="max-h-96 overflow-y-auto p-2.5 scrollbar-none divide-y divide-border-subtle">
          <Command.Empty className="py-8 text-center text-xs text-content-tertiary">
            No matching payments, issues, or settlements found.
          </Command.Empty>

          {/* Quick Actions Group */}
          <Command.Group
            heading="Quick Navigation"
            className="px-2 py-2 text-[10px] font-bold text-content-tertiary uppercase tracking-wider"
          >
            <Command.Item
              onSelect={() => runSelect(() => router.push('/payments'))}
              className="flex items-center gap-3 rounded-xl px-3 py-2 text-xs text-content-primary hover:bg-slate-100 cursor-pointer aria-selected:bg-slate-100 transition-colors"
            >
              <CreditCard className="h-4 w-4 text-content-tertiary" />
              <span>All Payments</span>
              <span className="ml-auto text-[10px] font-mono text-content-tertiary">Go to /payments</span>
            </Command.Item>

            <Command.Item
              onSelect={() => runSelect(() => router.push('/issues'))}
              className="flex items-center gap-3 rounded-xl px-3 py-2 text-xs text-content-primary hover:bg-slate-100 cursor-pointer aria-selected:bg-slate-100 transition-colors"
            >
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              <span>Issue Center</span>
              <span className="ml-auto text-[10px] font-mono text-content-tertiary">Go to /issues</span>
            </Command.Item>

            <Command.Item
              onSelect={() => runSelect(() => router.push('/settlements'))}
              className="flex items-center gap-3 rounded-xl px-3 py-2 text-xs text-content-primary hover:bg-slate-100 cursor-pointer aria-selected:bg-slate-100 transition-colors"
            >
              <Wallet className="h-4 w-4 text-content-tertiary" />
              <span>Settlement Health</span>
              <span className="ml-auto text-[10px] font-mono text-content-tertiary">Go to /settlements</span>
            </Command.Item>
          </Command.Group>

          {/* Active Issues Group */}
          <Command.Group
            heading="Active Issues"
            className="px-2 py-2 text-[10px] font-bold text-content-tertiary uppercase tracking-wider"
          >
            {issues.slice(0, 4).map((issue) => (
              <Command.Item
                key={issue.id}
                value={`${issue.id} ${issue.title} ${issue.description}`}
                onSelect={() =>
                  runSelect(() => {
                    const target =
                      issue.actionHref ||
                      (issue.relatedPaymentIds && issue.relatedPaymentIds.length > 0
                        ? `/payments/${issue.relatedPaymentIds[0]}`
                        : `/issues/${issue.id}`);
                    router.push(target);
                  })
                }
                className="flex items-center justify-between rounded-xl px-3 py-2.5 text-xs text-content-primary hover:bg-slate-100 cursor-pointer aria-selected:bg-slate-100 transition-colors gap-2"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span
                    className={`h-2 w-2 rounded-full shrink-0 ${
                      issue.severity === 'critical'
                        ? 'bg-rose-500 animate-pulse'
                        : issue.severity === 'warning'
                        ? 'bg-amber-500'
                        : 'bg-blue-500'
                    }`}
                  />
                  <div className="truncate">
                    <span className="font-semibold text-content-primary">{issue.title}</span>
                    <span className="text-content-secondary ml-2 text-[11px] truncate">
                      {issue.description}
                    </span>
                  </div>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  {issue.affectedAmount > 0 && (
                    <span className="font-semibold tabular-nums">
                      {formatCurrency(issue.affectedAmount)}
                    </span>
                  )}
                  <StatusBadge severity={issue.severity} size="sm" showDot={false} />
                </div>
              </Command.Item>
            ))}
          </Command.Group>

          {/* Live Payments Group */}
          <Command.Group
            heading="Recent Payments & Transactions"
            className="px-2 py-2 text-[10px] font-bold text-content-tertiary uppercase tracking-wider"
          >
            {payments.slice(0, 8).map((payment) => (
              <Command.Item
                key={payment.id}
                value={`${payment.id} ${payment.customer.name} ${payment.customer.email} ${payment.amount} ${payment.status}`}
                onSelect={() => runSelect(() => router.push(`/payments/${payment.id}`))}
                className="flex items-center justify-between rounded-xl px-3 py-2 text-xs text-content-primary hover:bg-slate-100 cursor-pointer aria-selected:bg-slate-100 transition-colors gap-2"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-medium">{payment.id}</span>
                    <span className="text-content-secondary truncate">
                      · {payment.customer.name}
                    </span>
                  </div>
                  <div className="text-[11px] text-content-tertiary truncate">
                    {payment.customer.email} · {payment.method.toUpperCase()}
                  </div>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  <span className="font-semibold tabular-nums text-sm">
                    {formatCurrency(payment.amount)}
                  </span>
                  <StatusBadge status={payment.status} size="sm" />
                </div>
              </Command.Item>
            ))}
          </Command.Group>
        </Command.List>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-border px-4 py-2 bg-surface-tertiary text-[11px] text-content-tertiary">
          <span>
            Use <kbd className="font-mono">↑</kbd> <kbd className="font-mono">↓</kbd> to navigate
          </span>
          <span>
            Press <kbd className="font-mono">↵</kbd> to select
          </span>
        </div>
      </Command>
    </div>
  );
}
